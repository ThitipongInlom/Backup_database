-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: cooperative
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Wed, 27 Nov 2019 03:16:45 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loan`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `l_id` int(255) NOT NULL,
  `m_id` int(255) NOT NULL,
  `l_amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `l_installment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `l_payments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `l_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `l_remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `loan` with 0 row(s)
--

--
-- Table structure for table `loan_detail`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_detail` (
  `ld_id` int(255) NOT NULL,
  `l_id` int(255) NOT NULL,
  `l_dateinstallment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ld_payments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ld_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ld_remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_detail`
--

LOCK TABLES `loan_detail` WRITE;
/*!40000 ALTER TABLE `loan_detail` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `loan_detail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `loan_detail` with 0 row(s)
--

--
-- Table structure for table `member`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `m_id` int(255) NOT NULL,
  `m_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m_datestart` date NOT NULL,
  `m_dateend` date NOT NULL,
  `m_remarkend` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m_savings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m_cp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `member` with 0 row(s)
--

--
-- Table structure for table `member_detail`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_detail` (
  `md_id` int(255) NOT NULL,
  `m_id` int(255) NOT NULL,
  `md_datepay` date NOT NULL,
  `md_amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `md_remark` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`md_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_detail`
--

LOCK TABLES `member_detail` WRITE;
/*!40000 ALTER TABLE `member_detail` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `member_detail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `member_detail` with 0 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Wed, 27 Nov 2019 03:16:45 +0100
