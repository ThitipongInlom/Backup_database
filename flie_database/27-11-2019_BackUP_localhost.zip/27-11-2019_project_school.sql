-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: project_school
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Wed, 27 Nov 2019 03:16:50 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data` (
  `data_id` int(12) NOT NULL AUTO_INCREMENT,
  `data_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_value` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `data` VALUES (1,'ประวัติความเป็นมาของข้าว','ข้าว ของไทยเป็นพืชอาหารประจำชาติที่มีตำนานประวัติศาสตร์มายาว นานปรากฏ เป็นร่องรอยพร้อมกับอารยธรรมไทยมาไม่น้อยกว่า 5,500 ปี ซึ่งมีหลักฐานจากแกลบข้าวที่เป็นส่วนผสมของดินใช้เครื่องปั้นดินเผาที่บ้าน เชียง อำเภอโนนนกทา ตำบลบ้านโคก อำเภอภูเวียง อันสันนิษฐานได้ว่าเป็น เมล็ดข้าวที่เก่แก่ที่สุดของไทยรวมทั้งยังพบหลักฐานเมล็ดข้าวที่ขุดพบที่ถ้ำ ปุงฮุง จังหวัดแม่ฮ่องสอนโดยแกลบข้าวที่พบนี้มีลักษณะของข้าวเหนียวเมล็ด ใหญ่ที่เจริญงอกงามในที่สูง\r\n \r\n     นอกจากนี้ยังมีการคันพบเมล็ดข้าว เถ้าถ่านในดินและรอยแกลบข้าวบนเครื่องปั้นดินเผาที่โคกพนมดี อำเภอพนัสนิคม จังหวัดชลบุรี แสดงให้เห็นถึงชุมชนปลูกข้าวสมัยก่อนประวัติศาสตร์ในแถบชายฝั่งทะเล รวมทั้งยังหลักฐานคล้ายดอกข้าวป่าที่ถ้ำเขาทะลุ จังหวัดกาญจนบุรี อายุประมาณ 2,800 ปี ซึ่งอยู่ในช่วงรอยต่อของยุคหินใหม่ตอนปลายกับยุคโลหะตอนต้น       \r\n      ภาพเขียนบนผนังถ้ำหรือผนังหินอายุประมาณ 6,000 ปี ที่ผาหมอนน้อย บ้านตากุ่ม ตำบลห้วยไผ่ อำเภอโขงเจียม จังหวัดอุบลราชธานี มีลักษณะคล้ายบันทึกการปลูกธัญพืชอย่างหนึ่งที่มีลักษณะเหมือข้าว ภาพควาย แปลงพืชคล้ายข้าว แสดงให้เห็นว่า มนุษย์ได้รู้จักการเพาะปลูกข้าวเป็นอย่างดีแล้ว\r\n\r\n      นัก วิทยาศาสตร์ชาวญี่ปุ่น 3 คน คือ Tayada Natabe, Tomoya Akihama และ Osamu Kinosgita แห่งมหาวิทยาลัย Tottri และ กระทรวงเกษตรและกรมป่าไม้ ได้ศึกษาวิจัยเกี่ยวกับเรื่องข้าวไทย ดูแกลบจากแผ่นอิฐโบราณจากโบราณสถาน 108 แห่งใน 39 จังหวัดทั่งทุกภาคของประเทศไทย ทำให้สันนิษฐานได้ว่า การปลูกข้าวในไทยมีมานานนับตั้งแต่พุทธศตวรรษที่ 6 โดยข้าวที่ปลูกจะเป็นข้าวเหนียวนาสวนเมล็ดป้อม และข้าวเหนียวไร่เมล็ดใหญ่ ต่อมาการปลูกข้าวเหนียวไร่น้อยลง แล้วเริ่มมีการปลูกข้าวนาสวนเมล็ดเรียวเพิ่มขึ้น\r\n\r\n     การศึกษาวิจัยนี้ทำให้ทราบว่า ในช่วงพุทธศตวรรษที่ 11-20 มีข้าวชนิดต่างๆ จำนวน 3 ขนาด คือ ข้าวเมล็ดใหญ่ ได้แก่ ข้าวเหนียวที่งอกงามในที่สูง ข้าวเมล็ดป้อม ได้แก่ ข้าวเหนียวที่งอกงามในที่ลุ่ม (ทั้งสองชนิดมีการเพาะปลูกก่อนสมัยทวาราวดี (พุทธศตวรรษที่ 11-16) และเมล็ดข้าวเรียว ได้แก่ ข้าวเจ้า พบในสมัยศรีวิชัย (พุทธศตวรรษที่ 13-18) ซึ่งข้าวแต่ละชนิดพบมากหรือน้อยแตกต่างกันไปตามระยะเวลา\r\n\r\n     ประมาณ พ.ศ. 540-570 ไทยได้รับอิทธิพลด้านกสิกรรมและการค้าจากจีน ซึ่งคาดว่ามาตามลำน้ำโขงสู่ดินแดนอีสานตอนล่าง ที่นิยมปลูกข้าวเหนียวเมล็ดป้อม และเมล็ดใหญ่กันอย่างแพร่หลาย เช่นเดียวกับภาคกลางในยุคทวาราวดี\r\n\r\n     ใน ช่วงเวลานั้นเริ่มมีการเพาะปลูกข้าวเจ้าเมล็ดยาวเรียวขึ้นแล้ว สันนิษฐานว่านำมาจากอาณาจักรขอม ซึ่งในยุคนั้นถือว่า เป็นชนชั้นปกครอง การหุงต้มข้าวเมล็ดยาวนี้แตกต่างจากข้าวของชาวพื้นเมือง จึงเชื่อว่าเป็นสาเหตุให้ข้าวชนิดนี้ถูกเรียกว่า “ข้าวเจ้า” และเรียกข้าวเหนียวว่า “ข้าวไพร่” บ้างก็เรียกว่า “ข้าวบ่าว” หรือ “ข้าวนึ่ง” ซึ่งข้าวในสมัยนั้นเรียกกันเป็นสิ่งบ่งบอกชนชั้นได้อีกด้วย\r\n\r\n     ใน สมัยกรุงสุโขทัย (พ.ศ. 1740-2040) ข้าวที่ปลูกในสมัยนี้ยังเป็นข้าวเหนียวเมล็ดป้อมและเมล็ดยาวเป็นส่วนใหญ่ แต่ก็เริ่มปลูกข้าวเจ้าเมล็ดยาวเรียวเพิ่มมากขึ้นตามลำดับ ในยุคนี้พระมหากษัตริย์ทรงทำนุบำรุงการกสิกรรม ได้ผลผลิตอุดมสมบูรณ์ ดังปรากฏในศิลาจารึกว่า “ในน้ำมีปลา ในนามีข้าว” มีการหักล้างถางพงและถือครองเป็นที่ทำกิน และที่ดินนั้นจะสืบทอดเป็นมรดกตกทอดแก่ลูกหลาน การสร้างหลักปักฐานเพื่อประกอบอาชีพกสิกรรมเช่นนี้ ก่อให้เกิดระบบการปกครอง เศรษฐกิจและสังคมขึ้น ดังนั้น ระบบศักดินาซึ่งเป็นการแบ่งระดับชนชั้นตามจำนวนของพื้นที่นาจึงน่าจะเริ่มใน ยุคนี้\r\n\r\n     ต่อ มาเข้าสู่สมัยกรุงศรีอยุธยาตอนต้น บ้านเมืองมีความมั่งคั่งเป็นอู่ข้าวอู่น้ำที่สำคัญ อีกทั้งหัวเมืองในอาณาจักรจำนวนมาก เริ่มระบบการปกครองแบบจตุสดมภ์มี “กรมนา” ดูแลและส่งเสริมและสนับสนุนการทำนาอย่างจริงจัง เพราะข้าวเป็นอาหารหลักของประชากรและเป็นเสบียงสำรองในยามเกิดศึกสงคราม โดยข้าวที่ปลูกส่วนใหญ่ยังคงเป็นข้าวเหนียวเมล็ดป้อม และเมล็ดยาว แต่การปลูกข้าวเจ้าเมล็ดยาวเรียวมากขึ้นด้วย\r\n\r\n     สมัย กรุงศรีอยุธยาตอนปลาย-กรุงรัตนโกสินทร์ตอนต้นในต้นรัชสมัยรัชกาลที่ 3 ได้มีการเก็บอากรข้าวในภาคกลาง ส่วนใหญ่เป็นพันธุ์ข้าวที่ทางราชการแนะนำ หรือพันธุ์พื้นเมืองที่มีคุณภาพ ส่วนภาคเหนือตอนบนนิยมปลูกข้าวเหนียว แต่ในภาคเหนือตอนล่างและภาคใต้เน้นปลูกข้าวเจ้าเป็นหลัก\r\n\r\n     ใน ช่วงนี้เองที่ประเทศตะวันตกได้ออกล่าอาณานิคม และเมืองไทยเป็นหนึ่งในเป้าหมาย แต่ด้วยพระปรีชาญาณ และวิเทโศบายอันชาญฉลาดของพระมหากษัตริย์ทุกพระองค์ ไทยจึงรอดพ้นเงื้อมมือของต่างชาติ และดำรงเอกราชอยู่ได้ ซึ่งส่วนหนึ่งคือ การเปิดเสรีการค้ากับต่างประเทศมากขึ้น ส่งผลให้ข้าวกลายเป็นสินค้าออกที่สำคัญของไทย รัฐบาลต้องขยายพื้นที่เพาะปลูก เพิ่มปริมาณผลผลิตข้าวในเขตพื้นที่ราบลุ่มแม่น้ำเจ้าพระยา ที่มีความอุดมสมบูรณ์มากที่สุด\r\n\r\n      ปัจจุบัน การปลูกข้าวในประเทศไทย คงมีเพียงข้าวเมล็ดป้อมที่พบมากในภาคเหนือ และภาคตะวันออกเฉียงเหนือ ขณะที่ข้าวเมล็ดยาว พบมากในภาคกลางและภาคใต้ ที่มีความอุดมสมบูรณ์มากที่สุด\r\nภาคตะวันออกเฉียงเหนือมีพื้นที่ปลูกข้าว คิดเป็น 45 % ของพื้นที่เพาะปลูกทั้งประเทศ ส่วนใหญ่ปลูกข้าวหอมมะลิ 105 ซึ่งเป็นข้าวคุณภาพดีที่สุดของโลก ข้าวที่ปลูกในพื้นที่แถบนี้จึงมักปลูกไว้เพื่อขาย รองลงมาคือ ภาคกลาง และภาคเหนือ ที่พื้นที่เพาะปลูกเท่ากันประมาณ 25%\r\nทุกวันนี้ไทยเป็นแหล่งปลูกข้าวที่ผลิตออกสู่ตลาดโลกมากที่สุด และเป็นศูนย์กลางของการศึกษาวิจัยพันธุ์ข้าว ซึ่งแสดงให้เห็นถึงบทบาทของผู้สร้างตำนานแห่งอารยธรรมธัญญาหาร ของมนุษยชาติ',NULL,NULL);
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `data` with 1 row(s)
--

--
-- Table structure for table `image`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `image_id` int(12) NOT NULL AUTO_INCREMENT,
  `image_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `image` VALUES (6,'คำแนะนำการใช้ปุ๋ยเคมีในนาข้าว','9e80d5eea1eff6e42fea1632cbe23c720c312d33.jpg','2019-10-03 11:26:23','2019-10-03 11:26:23');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `image` with 1 row(s)
--

--
-- Table structure for table `user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user` VALUES (1,'nice','$2y$10$HW7sv2qfUXiubcxyMRCS.ehmDYcFEWnzTBgIQ2YFlRA62HLmhPv22',NULL,'Thitipong','admin','ltK78ZFZVroSlYi8SZBNpF5ERLEtC8gf6Z20iIS5','::1','2019-08-10 09:19:46','2019-10-03 09:48:01');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `user` with 1 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Wed, 27 Nov 2019 03:16:50 +0100
