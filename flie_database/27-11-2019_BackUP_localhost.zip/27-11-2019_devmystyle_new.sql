-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: devmystyle_new
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Wed, 27 Nov 2019 04:08:43 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `category_id` int(12) NOT NULL AUTO_INCREMENT,
  `category_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `category` VALUES (1,'HTML','fab fa-html5',NULL,NULL),(2,'PHP','fab fa-php',NULL,NULL),(3,'JavaScript','fab fa-js-square',NULL,NULL),(4,'Bootstrap','fab fa-bootstrap',NULL,NULL),(5,'CSS','fab fa-css3',NULL,NULL);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `category` with 5 row(s)
--

--
-- Table structure for table `download`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `download` (
  `download_id` int(12) NOT NULL AUTO_INCREMENT,
  `download_post_id` int(12) DEFAULT NULL,
  `download_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `download_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `download_count` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`download_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `download`
--

LOCK TABLES `download` WRITE;
/*!40000 ALTER TABLE `download` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `download` VALUES (1,20,'สอนการตัดเศษทศนิยม ด้วย PHP','ed3c78567e23416ca5608886a267495cb91557ef.rar',NULL);
/*!40000 ALTER TABLE `download` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `download` with 1 row(s)
--

--
-- Table structure for table `post`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `post_id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blog` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '1 = on / 0 = off',
  `youtube` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '1 = on / 0 = off',
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '1 = on / 0 = off',
  `download` int(50) DEFAULT NULL COMMENT '1 = on / 0 = off',
  `count_view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `post` VALUES (1,'ตอนที่ 1 Bootstrap เบื้องต้น','ตอนที่-1-Bootstrap-เบื้องต้น','Bootstrap','ae7c35da09e14adcf10004a1ad06923f1bcc37d5.jpg','1','1','1',1,'45','jhkGP4bizuY','8.35','2019-10-29 08:24:43','2019-10-29 08:24:46'),(2,'ตอนที่ 1 ภาษา HTML เบื้องต้น','ตอนที่-1-ภาษา-HTML-เบื้องต้น','HTML','e617615ffdc69ffd69d913aef720efa270959a33.jpg','1','1','1',1,'63','fAYAEJ1XBDY','6.03','2019-10-29 09:19:26','2019-11-14 14:06:50'),(3,'ตอนที่ 1 ภาษา PHP เบื้องต้น','ตอนที่-1-ภาษา-PHP-เบื้องต้น','PHP','24564dad27569e8578ca893b0065137e21923977.jpg','1','1','1',1,'31','kQMj4enOpVY','8.42','2019-11-05 08:06:12','2019-11-05 08:06:15'),(4,'ตอนที่ 1 ภาษา JavaScript เบื้องต้น','ตอนที่-1-ภาษา-JavaScript-เบื้องต้น','JavaScript','cf3c3ce9aa380fa7a9e13e0cb6a965283d9aced9.jpg','1','1','1',1,'73','IDmyFcj0gys','10.59','2019-11-05 15:28:13','2019-11-23 05:35:51'),(5,'ตอนที่ 1 CSS เบื้องต้น','ตอนที่-1-CSS-เบื้องต้น','CSS','e645fa4f058bf93c5846395ea50f88437c4fdb83.jpg','1','1','1',1,'27','fvgvDeu6TDI','7.56','2019-11-05 15:29:49','2019-11-05 15:29:52'),(6,'ตอนที่ 2 ภาษา HTML เบื้องต้น','ตอนที่-2-ภาษา-HTML-เบื้องต้น','HTML','7bd3597078d3327193e52a4f0304a2eed935a47a.jpg','1','1','1',1,'498','wlmldJx4uw4','9.34','2019-11-05 15:31:29','2019-11-25 04:51:43'),(7,'ตอนที่ 2 ภาษา PHP เบื้องต้น Mysqli_Connect','ตอนที่-2-ภาษา-PHP-เบื้องต้น-Mysqli_Connect','PHP','34f201648e1e694afb86a100b59cd0d412b05613.jpg','1','1','1',1,'68','EZ9quQCPUz0','11.12','2019-11-05 15:32:40','2019-11-05 15:32:45'),(8,'ตอนที่ 2 Ajax Select / Option หมวดหมู่ห้อง','ตอนที่-2-Ajax-Select-Option-หมวดหมู่ห้อง','Bootstrap','7c143ed2cc1400cbaed3da8ffce0c6c8e97ca0d2.jpg','1','1','1',1,'81','4ZQpnXpNC94','4.42','2019-11-05 15:33:58','2019-11-05 15:34:00'),(9,'สอนการใช้งาน Sweet Alert เบื้องต้น','สอนการใช้งาน-Sweet-Alert-เบื้องต้น','JavaScript','0fab9b9de31d3489b6cc9985055123a3836d16a1.jpg','1','1','1',1,'44','b83i-GzNCqs','9.55','2019-11-05 15:35:53','2019-11-23 03:55:55'),(10,'การใช้ Marquee Code ในภาษา HTML','การใช้-Marquee-Code-ในภาษา-HTML','HTML','5795d3c384c25cf1b9450105c4930a6f1e7501c5.jpg','1',NULL,'1',1,'93',NULL,NULL,'2019-11-05 15:36:54','2019-11-23 03:55:42'),(11,'ตอนที่ 1 สอนทำ ระบบล็อกอิน ด้วย PHP Mysqli','ตอนที่-1-สอนทำ-ระบบล็อกอิน-ด้วย-PHP-Mysqli','PHP','3c1446683f234472ded32e7839778ff154dc8351.jpg','1','1','1',1,'73','6kS078mbN4o','14.25','2019-11-05 15:38:53','2019-11-23 05:33:08'),(12,'ตอนที่ 2 สอนทำ ระบบล็อกอิน ด้วย PHP Mysqli','ตอนที่-2-สอนทำ-ระบบล็อกอิน-ด้วย-PHP-Mysqli','PHP','7348f22f82ef98614086dfc1079a6122b159746d.jpg','1','1','1',1,'45','d1e8xjV1Ylg','13.25','2019-11-05 15:39:55','2019-11-05 15:39:57'),(13,'ตอนที่ 3 สอนทำ ระบบล็อกอิน ด้วย PHP Mysqli','ตอนที่-3-สอนทำ-ระบบล็อกอิน-ด้วย-PHP-Mysqli','PHP','4ff9215182c108df1412d81db47bd8472e16e871.jpg','1','1','1',1,'66','FR6oyy9EWtw','18.42','2019-11-05 15:40:55','2019-11-05 15:40:57'),(14,'สอนการใช้งาน ปลั้กอิน fontawesome','สอนการใช้งาน-ปลั้กอิน-fontawesome','HTML','b46c52b3941e8cc1b5dc3498e471e3cc5aaf1e4a.jpg','1','1','1',1,'51','joUIy8A6ERw','11.45','2019-11-05 15:42:01','2019-11-05 15:42:04'),(15,'ตอนที่ 2 Bootstrap เบื้องต้น','ตอนที่-2-Bootstrap-เบื้องต้น','Bootstrap','1d2d9e6b4f7e8f1128bd79fc78e1b120a1c4b7fc.jpg','1','1','1',1,'48','UQG9Ayif3FE','12.22','2019-11-05 15:43:15','2019-11-05 15:43:18'),(16,'ตอนที่ 1 รับส่งค่า ระหว่าง Javascript กับ PHP ด้วย Ajax','ตอนที่-1-รับส่งค่า-ระหว่าง-Javascript-กับ-PHP-ด้วย-Ajax','JavaScript','0f68c1d77593c48c55f80ea57dfde90ad0ff25cd.jpg','1','1','1',1,'47','EVVLBpf2h0M','11.40','2019-11-05 15:44:39','2019-11-23 05:30:54'),(17,'ตอนที่ 2 รับส่งค่า ระหว่าง Javascript กับ PHP ด้วย Ajax','ตอนที่-2-รับส่งค่า-ระหว่าง-Javascript-กับ-PHP-ด้วย-Ajax','JavaScript','1e1ffffe768f702e33eae22c2a92d8807cb9fd2d.jpg','1','1','1',1,'47','bMmRZXI-TNg','7.46','2019-11-05 15:45:48','2019-11-23 03:55:48'),(18,'สอนติดตั้ง codeigniter','สอนติดตั้ง-codeigniter','PHP','36c029848266a20148cdad3a0d50587ca757fce2.jpg','1','1','1',1,'34','JYg7Y4AHF6o','7.58','2019-11-05 15:46:50','2019-11-05 15:46:53'),(19,'สอนติดตั้ง laravel','สอนติดตั้ง-laravel','PHP','fcfdfafaf860ed123f66544f3536da98722a9298.jpg','1','1','1',1,'48','XsjGUMRynJs','8.26','2019-11-05 15:47:48','2019-11-05 15:47:51'),(20,'สอนการตัดเศษทศนิยม ด้วย PHP','สอนการตัดเศษทศนิยม-ด้วย-PHP','PHP','fcfaa8c24e972a5fa827a98bb6b1d97fc2693a5d.jpg','1','1','1',1,'77','yloqiHQ3_CE','30.38','2019-11-05 15:48:49','2019-11-22 08:18:56');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `post` with 20 row(s)
--

--
-- Table structure for table `tag`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tag_id` int(12) NOT NULL AUTO_INCREMENT,
  `post_id` int(12) DEFAULT NULL,
  `tag_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tag` VALUES (1,2,'ภาษา HTML','2019-11-08 07:10:23','2019-11-08 07:10:26'),(2,3,'ภาษา PHP','2019-11-08 07:10:29','2019-11-08 07:10:31'),(3,8,'Ajax','2019-11-08 07:10:33','2019-11-08 07:10:36'),(4,10,'HTML','2019-11-08 07:10:38','2019-11-08 07:10:41'),(5,8,'ภาษา Javascript','2019-11-12 09:11:01','2019-11-12 09:11:03'),(6,4,'ภาษา PHP','2019-11-12 09:11:06','2019-11-12 09:11:08');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tag` with 6 row(s)
--

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `u_id` int(12) NOT NULL AUTO_INCREMENT COMMENT 'user_id',
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'username',
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'password',
  `u_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'name',
  `u_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `users` VALUES (1,'nice','$2y$10$aiGeiXyBVzSKY03EyJzeU.FRNpLh7eFaPLFuNU5Wr1OiP1C1fpb3e','Thitipong Inlom','ingnice007@gmail.com','admin','2019-11-08 09:21:31','2019-11-08 09:21:31');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `users` with 1 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Wed, 27 Nov 2019 04:08:43 +0100
