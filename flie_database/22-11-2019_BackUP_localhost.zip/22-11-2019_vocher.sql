-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: vocher
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Fri, 22 Nov 2019 10:05:26 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `username_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `hotel` varchar(255) NOT NULL,
  `typestaff` varchar(255) NOT NULL,
  `ip_login` varchar(255) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`username_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `employee` VALUES (1,'nice','$2y$10$HW7sv2qfUXiubcxyMRCS.ehmDYcFEWnzTBgIQ2YFlRA62HLmhPv22','Thitipong Inlom','IT','Thezign','Admin','::1','Bp4gkQFzA8ce8TrSLo6Ve88MjllSqio4lFjWjZ2E',NULL,'2019-09-30 10:01:57'),(9,'test','$2y$10$M5WzMaSX5kH83bfpOe8deuJipoqOkREY.CSkierPH2Iit6zJ2Yzui','test','IT','Thezign','User','::1','LoYmbuoiymI3tsp3cC7wdE9nAIduCqQTV8T6EnWgBJYBzByRFtp8EuaCdSQc','2019-09-27 01:40:12','2019-09-30 07:18:09'),(10,'test2','$2y$10$z7vwVSoQ7x/q.uinysvC7eOHKcc9mnyfx0rb4svROMYyGkSfBBtRq','test','IT','Thezign','User','::1','4NMH930pQHNfdR6RW3KrLr3rc5ccztiugyIpLx7aUabhvMhfymoAcu7R46PT','2019-09-28 07:17:48','2019-09-30 07:18:37'),(11,'katuy','$2y$10$TGRZwkRtjda2GJkbK2lSWuUJ7ghcupOCy3YxOaHSOVA9YZQNBl04u','Ruttiporn Kundachanuwat','IT','Thezign','Admin','172.16.1.243','JmJluPk56W67ixY27qHBjAJz7ODlEqDbGU3qSv3wltOHn80kQa7avjz0Njbr','2019-09-28 07:26:00','2019-09-28 07:27:13');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `employee` with 4 row(s)
--

--
-- Table structure for table `hotel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel` (
  `hotelcode` varchar(255) NOT NULL,
  `hotelname` varchar(255) NOT NULL,
  PRIMARY KEY (`hotelcode`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `hotel` with 0 row(s)
--

--
-- Table structure for table `menu`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `menu_id` int(12) NOT NULL AUTO_INCREMENT,
  `row_number` int(12) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `type_click` varchar(255) DEFAULT NULL,
  `group` varchar(255) DEFAULT NULL,
  `group_row_number` int(12) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `url_link` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `menu` VALUES (1,1,'main','single','group_1',0,'หน้าหลัก','fas fa-tachometer-alt','/','open',NULL,'2019-09-28 07:12:04'),(2,3,'main','group','group_2',0,'ตั้งค่า','fas fa-cogs','#','open',NULL,'2019-09-28 07:15:20'),(3,0,'sub','group','group_2',1,'ตั้งค่า เมนู','fas fa-tachometer-alt','/setting_menu','open',NULL,'2019-09-30 07:19:06'),(4,0,'sub','single','group_2',2,'ตั้งค่า User','fas fa-angry','/employee','open',NULL,'2019-09-30 07:19:06');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `menu` with 4 row(s)
--

--
-- Table structure for table `user_menu`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_menu` (
  `user_menu_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `menu_id` int(12) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `type_control` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_menu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_menu`
--

LOCK TABLES `user_menu` WRITE;
/*!40000 ALTER TABLE `user_menu` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user_menu` VALUES (33,'nice',1,'หน้าหลัก','Full','2019-09-28 04:18:28','2019-09-28 04:18:28'),(34,'nice',2,'ตั้งค่า','Full','2019-09-28 04:18:28','2019-09-28 04:18:28'),(35,'nice',3,'ตั้งค่า เมนู1','Full','2019-09-28 04:18:28','2019-09-28 04:18:28'),(36,'nice',4,'สร้าง User','Full','2019-09-28 04:18:28','2019-09-28 04:18:28'),(37,'nice',5,'ตั้งค่า เมนู2','Full','2019-09-28 04:18:28','2019-09-28 04:18:28'),(38,'test',1,'หน้าหลัก','Denie','2019-09-28 04:18:28','2019-09-28 04:18:28'),(39,'test',2,'ตั้งค่า','Denie','2019-09-28 04:18:28','2019-09-28 04:18:28'),(40,'test',3,'ตั้งค่า เมนู1','Denie','2019-09-28 04:18:28','2019-09-28 04:18:28'),(41,'test',4,'สร้าง User','View','2019-09-28 04:18:28','2019-09-28 07:11:35'),(42,'test',5,'ตั้งค่า เมนู2','Denie','2019-09-28 04:18:28','2019-09-28 04:18:28'),(43,'test2',1,'หน้าหลัก','Denie','2019-09-28 07:17:48','2019-09-28 07:17:48'),(44,'test2',2,'ตั้งค่า','Denie','2019-09-28 07:17:48','2019-09-28 07:17:48'),(45,'test2',3,'ตั้งค่า เมนู1','Denie','2019-09-28 07:17:48','2019-09-28 07:17:48'),(46,'test2',4,'สร้าง User','Denie','2019-09-28 07:17:48','2019-09-28 07:17:48'),(47,'test2',5,'ตั้งค่า เมนู2','Denie','2019-09-28 07:17:48','2019-09-28 07:17:48'),(48,'katuy',1,'หน้าหลัก','Full','2019-09-28 07:26:00','2019-09-28 07:26:22'),(49,'katuy',2,'ตั้งค่า','Full','2019-09-28 07:26:00','2019-09-28 07:26:22'),(50,'katuy',3,'ตั้งค่า เมนู1','Full','2019-09-28 07:26:00','2019-09-28 07:27:33'),(51,'katuy',4,'สร้าง User','Full','2019-09-28 07:26:00','2019-09-28 07:26:22'),(52,'katuy',5,'ตั้งค่า เมนู2','Full','2019-09-28 07:26:00','2019-09-28 07:27:33');
/*!40000 ALTER TABLE `user_menu` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `user_menu` with 20 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Fri, 22 Nov 2019 10:05:26 +0100
