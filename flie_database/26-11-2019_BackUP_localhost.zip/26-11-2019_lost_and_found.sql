-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: lost_and_found
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Tue, 26 Nov 2019 08:35:49 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `list_item`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `list_item` (
  `list_id` int(12) NOT NULL AUTO_INCREMENT,
  `place_found` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_detail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_found` date DEFAULT NULL,
  `guest_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `check_in_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `check_out_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `found_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locate_track` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `record_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `return_item` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_item_out` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dep_item_out` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_item_out` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_item_out` date DEFAULT NULL,
  `name_return_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_return_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_return_guest` date DEFAULT NULL,
  `phone_return_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dep_return_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ems_return_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other_return_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_item`
--

LOCK TABLES `list_item` WRITE;
/*!40000 ALTER TABLE `list_item` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `list_item` VALUES (2,'ตึก A','เงิน','จำนวนเงิน 300บาท','2019-08-10','-','-','-','ไนช์','IT','nice','HK วิลล่า','2b22e661796017b1a31804a0a9f289d9739a35eb.gif',NULL,NULL,'turn','TT','IT','1','2019-08-12','A','A','2019-08-14','A',NULL,NULL,NULL),(3,'aa','เงิน','22','2019-08-10','-','-','-','w','IT','nice','HK เดอะซายน์','9214207e2032f38906be4b09eb292841ee91739c.png',NULL,NULL,'turn','TT','t','2','2019-08-12','A','A',NULL,NULL,'A','A',NULL),(4,'test','เงิน','test','2019-08-13','-','-','-','test','TE','nice','HK วิลล่า','256c8706821a5b1c9145bb9cf6f57a17a2955e12.gif',NULL,NULL,'turn','Thitipoong','ITA','3','2019-08-14',NULL,NULL,NULL,NULL,NULL,NULL,'ทดสอบ อื่นๆ'),(5,'T','เงิน','T','2019-08-14','-','-','-','T','T','nice','HK วิลล่า','9dfebe5c78393e7a3e56413ca0d7f7faaf73f70f.png',NULL,NULL,'wait','666','333','2','2019-08-24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'A','นาฬิกา','A','2019-08-24','-','-','-','A','A','nice','HK วิลล่า','9f17dc0fac7965539a7224384ea5491482a57826.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'A','นาฬิกา','D','2019-07-30','-','-','-','D','D','nice',NULL,'9f17dc0fac7965539a7224384ea5491482a57826.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'B','TEST','B','2019-08-24','-','-','-','B','B','nice','หน้าฟร้อน Z2','627c4bddb074321518a375c745e08b03ff43f9d8.gif',NULL,NULL,'wait','ทดสอบ','IT','1','2019-09-06',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'ทดสอบ Place','TEST','TT','2019-08-26','-','-','-','ไนช์','IT','test','HK วิลล่า','f079dbcdb7b367f4ec1eaec8821a94a5947e46b2.gif',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'A','TEST','A','2019-09-06','-','-','-','A','A','nice','ทั้งหมด','fdd32d42e1e42078053eab6522ea9ba1719d694d.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `list_item` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `list_item` with 9 row(s)
--

--
-- Table structure for table `type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type` (
  `type_id` int(12) NOT NULL AUTO_INCREMENT,
  `type_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_show` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type`
--

LOCK TABLES `type` WRITE;
/*!40000 ALTER TABLE `type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `type` VALUES (1,'item','เงิน','show','2019-08-26 09:39:18','2019-08-26 11:50:02'),(2,'item','TEST','show','2019-08-16 09:09:39','2019-08-14 15:20:23'),(4,'item','นาฬิกา','show','2019-08-24 10:03:52','2019-08-24 10:03:52'),(5,'item','ทอง','show','2019-08-24 10:07:49','2019-08-24 10:07:49'),(6,'place','HK วิลล่า','show','2019-08-26 09:39:45','2019-08-26 10:07:49'),(15,'place','HK เดอะซายน์','show','2019-08-26 16:18:00','2019-08-26 16:18:00');
/*!40000 ALTER TABLE `type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `type` with 6 row(s)
--

--
-- Table structure for table `user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place_view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user` VALUES (1,'nice','$2y$10$HW7sv2qfUXiubcxyMRCS.ehmDYcFEWnzTBgIQ2YFlRA62HLmhPv22','Thitipong','Inlom','0864633160','ingnice007@gmail.com','admin','thai',NULL,NULL,'QIweiRJEgSZQcADGul0X2hU6chpq3ExqB55UHSij','::1','2019-08-10 09:19:46','2019-11-09 13:28:13'),(8,'A','$2y$10$idNmaIViUDE5b5CDxvPpo.8P4rwnRfQmjAbUYWsnuzVVmQGXEATGa','A','A','-','-','user',NULL,NULL,NULL,'34tt74xNruhhROAdfaZLFjbIzX0dzgEwYpAABFTDADeKMmbjbbUTQ8wRePm5','::1','2019-09-07 11:51:52','2019-09-10 10:32:34');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `user` with 2 row(s)
--

--
-- Table structure for table `web_setting`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_setting` (
  `setting_id` int(12) NOT NULL AUTO_INCREMENT,
  `setting_titel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `setting_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_setting`
--

LOCK TABLES `web_setting` WRITE;
/*!40000 ALTER TABLE `web_setting` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `web_setting` VALUES (1,'system_ver','0.0.1',NULL,NULL);
/*!40000 ALTER TABLE `web_setting` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `web_setting` with 1 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Tue, 26 Nov 2019 08:35:49 +0100
