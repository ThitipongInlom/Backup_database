-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: remote_50
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Tue, 26 Nov 2019 08:35:52 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `changehistorys`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changehistorys` (
  `changehistory_id` int(12) NOT NULL AUTO_INCREMENT,
  `sticker_number` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_old` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_change` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_change` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`changehistory_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changehistorys`
--

LOCK TABLES `changehistorys` WRITE;
/*!40000 ALTER TABLE `changehistorys` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `changehistorys` VALUES (1,'COM001','License',NULL,'Active','เพิ่มข้อมูลใหม่',NULL,'nice','2019-08-24 10:52:24','2019-08-24 10:52:24');
/*!40000 ALTER TABLE `changehistorys` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `changehistorys` with 1 row(s)
--

--
-- Table structure for table `departments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `department_id` int(12) NOT NULL AUTO_INCREMENT,
  `department_titel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_main` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`department_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `departments` VALUES (5,'AC','AC'),(6,'AP','AP'),(7,'ARTIS','Artis'),(8,'CHIFAN','Chifan'),(9,'CONTROL','Control'),(10,'DAZZLE LOUNGE','Dazzle Lounge'),(11,'DESSIN','Dessin'),(12,'EN','EN'),(13,'EXC','EXC'),(14,'FB','FB'),(15,'FN','FN'),(16,'FO','FO'),(17,'FO VILLA','FO Villa'),(18,'GUEST A','Guest A'),(19,'GUEST B','Guest B'),(20,'HK','HK'),(21,'HK VILLA','HK Villa'),(22,'HM','HM'),(23,'HR','HR'),(24,'IT','IT'),(25,'LAUNDRY','Laundry'),(26,'MK','MK'),(27,'MOOD','Mood'),(28,'OPERATOR','Operator'),(29,'RECEIVING','Receiving'),(30,'RESERVATION','Reservation'),(31,'ROOMSERVICE','RoomService'),(32,'SCARLET','Scarlet'),(33,'SPA','Spa'),(34,'SPARE','spare'),(35,'STEWARD','Steward'),(36,'STORE','Store');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `departments` with 32 row(s)
--

--
-- Table structure for table `hotels`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotels` (
  `hotel_id` int(12) NOT NULL AUTO_INCREMENT,
  `hotel_titel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hotel_main` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hotel_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotels`
--

LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `hotels` VALUES (1,'Thezign',NULL),(2,'Tsix5',NULL),(3,'Way',NULL),(4,'Z-Through',NULL),(5,'Garden Seaview',NULL);
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `hotels` with 5 row(s)
--

--
-- Table structure for table `item`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `item_id` int(12) NOT NULL AUTO_INCREMENT,
  `sticker_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dep` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hotel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `case` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monitor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mouse` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keyboard` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mainboard` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `powersupply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hdd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ssd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ups` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ups_battery` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `windows` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `teamviewer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anydesk` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `computer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_main` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_sub` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `internet` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `item` VALUES (1,'COM001','FB','Thezign','ทอย','7310','Pentium(R) Dual-Core  CPU      E5500  @ 2.80GHz','2TB',NULL,'SAMSUNG','Logitech','Lenovn',NULL,NULL,'298.1GB',NULL,'ZU001',NULL,'Microsoft Windows 7 ','952971042','468044035','ZHAFB','172.16.1.144','187.217.0.144','Enable','Active'),(2,'COM002','FB','Thezign','อิ๋ว','7311','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','2048MB',NULL,'PHILIPS I9IEL 21','Logitouch M100','Lenovo',NULL,NULL,'149.0GB',NULL,'-',NULL,'Microsoft Windows 7 ','483123321','709234896','ZHFB-PC','172.16.1.142','187.217.0.142','Enable',NULL),(3,'COM003','FB','Thezign','คุณสุรชัย','7300','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','1024MB',NULL,'Samsung SyncMaster740N','Optical Mouse','Sansung PLEOMAX',NULL,NULL,'74.5GB',NULL,'ZU002',NULL,'Microsoft Windows XP','179696939','778887243','FBMGR','172.16.1.143','187.217.0.143','Enable',NULL),(4,'COM004','HK','Thezign','ออฟฟิส','6','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','4GB',NULL,'Acer','Genius','MD tech','A.M.I.-7000831',NULL,'-','240GB','-',NULL,'Microsoft Windows 7 ','1185761480','847130972','ZHHKTHEZIGN-PC','172.16.1.151','187.217.0.151','Enable',NULL),(5,'COM005','AC','Thezign','คุณต่อยศ','7606','Intel(R) Core(TM) i3-3240 CPU @ 3.40GHz','3295MB',NULL,'SyncMaster740n 17.1\" (34cm x 27cm)','M-UAG96B','KER',NULL,NULL,'931.5GB',NULL,'ZU004',NULL,'Microsoft Windows 10','264812239','106154314','ZHARACCOUNT','172.16.1.208','187.217.0.208','Enable',NULL),(6,'COM006','AC','Thezign','คุณนิ','-','Intel(R) Pentium(R) CPU G4400 @ 3.30GHz','2TB',NULL,'SAMSUNG','-','Logitech',NULL,NULL,'931.5GB',NULL,'ZU005',NULL,'Microsoft Windows 10','1024117034','279662311','ZHAC5','172.16.1.202','187.217.0.202','Enable',NULL),(7,'COM007','AC','Thezign','พี่อ้อน','7604','Pentium(R) Dual-Core  CPU      E5500  @ 2.80GHz','2GB',NULL,'PHILPS','Genius','-',NULL,NULL,'298.1GB',NULL,'ZU007',NULL,'Microsoft Windows 7 ','1038601587','-','ZHFINANCE01','172.16.1.205','187.217.0.205','Enable',NULL),(8,'COM008','AC','Thezign','คุณแดง','7608','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','1024MB',NULL,'SyncMaster, 17.1\" (34cm x 27cm)','KER','KER',NULL,NULL,'74.5GB',NULL,'ZU006',NULL,'Microsoft Windows XP','789392274','725973623','ZHCOST01','172.16.1.201','187.217.0.201','Enable',NULL),(9,'COM009','AC','Thezign','พี่แพร','7603','Pentium(R) Dual-Core  CPU E5300  @ 2.60GHz','3 GB',NULL,'SyncMaster, 16.7\" (37cm x 21cm)','MD tech','MD tech',NULL,NULL,'931.5GB',NULL,'ZU008',NULL,'Microsoft Windows 7 ','893192836','145242 309','PAM_AR','172.16.1.210','187.217.0.210','Enable',NULL),(10,'COM010','AC','Thezign','พี่หว้า','7605','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','2048MB',NULL,'SyncMaster, 17.1\" (34cm x 27cm)','Philps','lenovo',' ',NULL,'931.5GB',NULL,'ZU009',NULL,'Microsoft Windows 7 ','546675565','579117358','ZHAR1','172.16.1.209','187.217.0.209','Enable',NULL),(11,'COM011','AC','Thezign','คุณเปิ้ล','7600','Intel(R) Core(TM) i3-4130 CPU @ 3.40GHz','3.7TB',NULL,'SAMSUNG','-','Logitech','',NULL,'223.6GB',NULL,'ZU010',NULL,'Microsoft Windows 10','1070492271','800178383','ZHACDOF','172.16.1.76','187.217.0.76','Enable',NULL),(12,'COM012','AC','Thezign','คุณต่อย','7601','Intel(R) Core(TM) i3-4160 CPU @ 3.60GHz','3267MB',NULL,'EB192Q, 18.5\" (41cm x 23cm)','Philips','KER','ASRock H81M-VG4 R2.0',NULL,'223.6GB',NULL,'ZU012',NULL,'Microsoft Windows 10','629137731','945169930','SUTHON','172.16.1.203','187.217.0.203','Enable',NULL),(13,'COM013','HR','Thezign','พี่แอม','7802','Intel(R) Core(TM) i3-6098P CPU @ 3.60GHz','3.7TB',NULL,'SAMSUNG','Logitech','Logitech','AsRock H110M',NULL,'1TB',NULL,'ZU015',NULL,'Microsoft Windows 10','533918815','226798101','ZHHRINSPECT01','172.16.1.164','187.217.0.164','Enable',NULL),(14,'COM014','AC','Thezign','คุณพงษ์','7602','Pentium(R) Dual-Core  CPU E5500  @ 2.80GHz','2048MB',NULL,'Philips 191E, 18.5\" (41cm x 23cm)','Logitech','lenovo','LENOVO Model:7099G5T Serial Number:S5BBVLZ',NULL,'298.1GB',NULL,'ZU011',NULL,'Microsoft Windows 7 ','970894855','792410150','ZHINCOME04-PC','172.16.1.69','187.217.0.69','Enable',NULL),(15,'COM015','AC','Thezign','คุณอุ๋ย','7606','Intel(R) Pentium(R) Gold G5500 CPU @ 3.80GHz','3753MB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','HP','Hp','ASRock H310M-HDV',NULL,'223.6GB SSD',NULL,'ZU013',NULL,'Microsoft Windows 10','1038254097','1038254097','DESKTOP-KUSLHRQ','172.16.1.206','187.217.0.206','Enable',NULL),(16,'COM016','AC','Thezign','คุณฉาย','7607','Genuine Intel(R) CPU 2140  @ 1.60GHz','512MB',NULL,'Samsung SyncMaster 740N','45','HP','ASUSTek Computer INC. P5GC-MX',NULL,'931.5GB',NULL,'ZU014',NULL,'Microsoft Windows XP','341327726','233562388','ZHPURCHES01','172.16.0.207','187.217.0.207','Enable',NULL),(17,'COM017','HR','Thezign','ออฟฟิส','7804','Genuine Intel(R) CPU 2140  @ 1.60GHz','1GB','VB','Lenovo L193 Wide, 18.6\" (40cm x 25cm)','Logitect 100r','Logitect K120','AsusTek P5GC-MX',NULL,'80GB',NULL,'ZU017',NULL,'Microsoft Windows XP','531576370','144380063','HRZ_PC','172.16.1.162','-','Enable',NULL),(18,'COM018','HR','Thezign','รวม','7804','Pentium(R) Dual-Core  CPU      E5300  @ 2.60GHz','2GB','Lenovo','HP L1706, 16.8\" (33cm x 27cm)','LVPOO','HP','LENOVO Model:7515RT5 Serial Number:R8LAWKA',NULL,'300GB',NULL,'ZU016',NULL,'Microsoft Windows 7 ','242092967','686642849','ADMIN','172.16.1.163','187.217.0.163','Enable',NULL),(19,'COM019','HR','Thezign','คุณนวลจันทร์','7800','Intel(R) Core(TM) i3-6100 CPU @ 3.70GHz','2212MB',NULL,'LE1911, 19.1\" (38cm x 30cm)','Aslis','HP','MSI Model:MS-7A15',NULL,'931.5GB',NULL,'ZU018',NULL,'Microsoft Windows 10','779743812','188168319','ZHDHR','172.16.1.165','187.217.0.165','Enable',NULL),(20,'COM020','FN','Thezign','แคชเชียร์','7673','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','4GB','Cubic','SAMSUNG','45','Signo','Gigabyte Technology Co., Ltd. AsRock H310CM',NULL,'-','240GB','ZU019',NULL,'Microsoft Windows 7 ','172.16.1.1','-','admin-pc','172.16.1.148','187.217.0.148','Disable',NULL),(21,'COM021','FN','Thezign','พี่ปลา','7670','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','1GB','computer','Samsung SyncMaster, 17.1\" (34cm x 27cm)','Asus','Logitech','Gigabyte Technology Co., Ltd. Model:945GCM-S2L',NULL,'80GB',NULL,'ZU020',NULL,'Microsoft Windows XP','583726697','940536418','ZFITNESS02','172.16.1.146','187.217.0.146','Enable',NULL),(22,'COM022','FN','Thezign','คุณประสิทธิ','7670','Intel(R) Pentium(R) Gold G5400 CPU @ 3.70GHz','3765MB',NULL,'Samsung SyncMaster 740N','Genius','Infinity','ASRock H310CM-DVS',NULL,'1.13TB',NULL,'ZU021',NULL,'Microsoft Windows 10','1087917728','808154687','ZHFITNESSMGR','172.16.1.174','-','Enable',NULL),(23,'COM023','FN','Thezign','Bar','7671','Genuine Intel(R) CPU 2160 @1.80GHz','1024MB',NULL,'Samsung','MD Tech','Lenovo','-',NULL,'240GB',NULL,'-',NULL,'Microsoft Windows XP','-','-','SPARE1','-','-','Disable',NULL),(24,'COM024','Spa','Thezign','คุณนิ้ง','7650','Intel(R) Pentium(R)Dual CPU E2160 @1.80GHz','1GB',NULL,'Samsung','-','-','-',NULL,'80GB',NULL,'ZU024',NULL,'Microsoft windows XP','','','ZHZSPA','172.16.1.172','187.217.0.172','Enable',NULL),(25,'COM025','Spa','Thezign','แคชเชียร์','7651','Genuine Intel(R) CPU 2140  @ 1.60GHz','1GB','Lenovo','1024 x 768 pixels, 65536 colours','Lenovo','MD Tech','Lenovo',NULL,'80GB',NULL,'ZU022',NULL,'Microsoft Windows XP','-','1099354062','ZPHORAR02','172.16.1.171','187.217.0.171','Disable',NULL),(26,'COM026','Spa','Thezign','รวม','7671','Intel(R) Prntium(R) Dual CPU E2160 @1.80GHz','1GB','computer','Samsung','Samsung','MD Tech','Philips',NULL,'250GB',NULL,'-',NULL,'XP','-','-','SPAREC','-','-','Disable',NULL),(27,'COM027','EN','Thezign','ปอย','7501','Pentium(R) Dual-Core  CPU      E5300  @ 2.60GHz','1GB',NULL,'Samsung','Ker','KER','LENOVO',NULL,'300GB',NULL,'ZU023',NULL,'Microsoft Windows XP','510193813','673073081','admin-c107','172.16.1.140','187.217.0.140','Enable',NULL),(28,'COM028','EN','Thezign','คุณเอ๋','7507','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','3GB',NULL,'Lenovo L193 Wide, 18.6\" (40cm x 25cm)','Logitech','signo','ASUTEK Computer',NULL,'120GB',NULL,'-',NULL,'Microsoft Windows 7 ','822690436','306559317','ZHEM','172.16.1.175','187.217.0.175','Enable',NULL),(29,'COM029','EN','Thezign','ออฟฟิส','7507','Intel(R) Core(TM) i3-6098P CPU @ 3.60GHz','4GB',NULL,'Acer B193L, 19.1\" (38cm x 30cm)','Lenovo','Microsoft','BIOSTAR Group H110MD PRO',NULL,'1TB',NULL,'-',NULL,'Microsoft Windows 10','823790906','904366583','ZHEN','172.16.1.177','-','Enable',NULL),(30,'COM030','EN','Thezign','Store','7504','Pentium(R) Dual-Core  CPU      E6500  @ 2.93GHz','2GB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','Lenovo','KER','ASUSTeK Computer INC. P5KPL AM/PS',NULL,'1TB',NULL,'ZU025',NULL,'Microsoft Windows 7 ','508496514','285722115','ZHEN1','172.16.1.176','-','Enable',NULL),(31,'COM031','Laundry','Thezign','เคริก','7329','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','3GB',NULL,'Lenovo L193 Wide, 18.6\" (40cm x 25cm)','Genius','45 x235U','Gigabyte Technology Co., Ltd.  945GCM-S2L',NULL,'500GB',NULL,'ZU026',NULL,'Microsoft Windows 7 ','255174177','229559148','ZHLD-PC','172.16.1.181','187.217.0.181','Disable',NULL),(32,'COM032','Laundry','Thezign','คุณทวีป','7329','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','2GB',NULL,'SAMSUNG','K120','Logitech','System manufacturer',NULL,'1TB',NULL,'ZU027',NULL,'Microsoft Windows 7 ','249855782','459343947','ZHASTLD','172.16.1.182','187.217.0.182','Enable',NULL),(33,'COM033','RoomService ','Thezign','RoomService ','2','Pentium(R) Dual-Core  CPU      E5400  @ 2.70GHz','1024MB',NULL,'SAMSUNG','-','MD tech','LENOVO',NULL,'298.1GB',NULL,'-',NULL,'Microsoft Windows XP','1284936006','352296738','INROOM01','172.16.1.141','187.217.0.141','Disable',NULL),(34,'COM034','MK','Thezign','ตลาด','7371','Intel(R) Core(TM)2 Duo CPU     E7300  @ 2.66GHz','3037MB',NULL,'Philips Compaq W185q, 18.5\" (41cm x 23cm)','45','MD tech','Model 0829AW2	  Serial Number	R8W2X0D	 ',NULL,'540.3GB',NULL,'ZU028',NULL,'Microsoft Windows 7 ','277915464','617473462','KITCHIEN','172.16.1.156','187.217.0.156','Enable',NULL),(35,'COM035','-','Thezign','สแปร','-','Genuine Intel(R) CPU  2140  @ 1.60GHz','1024MB',NULL,'-','-','-','-',NULL,'149.0GB',NULL,'-',NULL,'Microsoft Windows XP','-','-','-','-','-',NULL,NULL),(36,'COM036','Store','Thezign','คุณโซดา','7347','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','1024MB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','Logitech','Genius','945GCM-S2L',NULL,'298.1GB',NULL,'ZU030',NULL,'Microsoft Windows 7 ','673229361','729680788','STORE-PC','172.16.1.180','187.217.0.180','Enable',NULL),(37,'COM037','Dazzle Lounge','Thezign','แคชเชียร์','7321','Pentium(R) Dual-Core  CPU      E5400  @ 2.70GHz','1024MB',NULL,'SAMSUNG Compaq W185q, 18.5\" (41cm x 23cm)','lenovo','lenovo','7270RW1',NULL,'298.1GB',NULL,'-',NULL,'Microsoft Windows XP','406044261','-','DAZZLE','172.16.1.194','187.217.0.194','Disable',NULL),(38,'COM038','Steward','Thezign','คุณสมชาย','7390','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','1024MB',NULL,'SAMSUNG Philips 191EL, 18.5\" (41cm x 23cm)','Logiech','PHILIPS','System Product Name SYS-1234567890',NULL,'74.5GB',NULL,'-',NULL,'Microsoft Windows XP','681414720','-','ZH-STEWARD','172.16.1.83','-','',NULL),(39,'COM039','Receiving','Thezign','คุณเบียร์','7376','Intel(R) Core(TM) i3-4150 CPU @ 3.50GHz','3267MB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','Genius','MD tech','AsRock H81M-VG4',NULL,'931.5GB',NULL,'ZU003',NULL,'Microsoft Windows 10','415321382','788371038','RECEIVING','172.16.1.213','187.217.0.213','Disable',NULL),(40,'COM040','AC','Thezign','แคชเชียร์ A','5','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz256','2.5GB',NULL,'SASUNG SyncMaster, 17.1\" (34cm x 27cm)','Logiteh','KER','System Product Name SYS-1234567890',NULL,'80GB',NULL,'ZU031',NULL,'Microsoft Windows 7 ','-','439 649 13','ZHHROFFICE','172.16.1.195','187.217.0.195','Disable',NULL),(41,'COM041','AC','Thezign','แคชเชียร์ A','5','Intel(R) Core(TM) i3-6100 CPU @ 3.70GHz','4GB',NULL,'Philips 202EL, 19.9\" (44cm x 25cm)','Logitech ','Logitech K120','Model:10L0001BTB Serial Number:PC0DNGDL',NULL,'1TB',NULL,'ZU032',NULL,'Microsoft Windows 7 ','414815036','474602224','ZHCASHIERB','172.16.1.196','187.217.0.196','Disable',NULL),(42,'COM042','FO','Thezign','รวม','4','Intel(R) Core(TM) i3-6100 CPU @ 3.70GHz','4GB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','Logitech M100r','HP','ASRock H110M DVS R3.0',NULL,'931.5GB',NULL,'-',NULL,'Microsoft Windows 10','-','685546351','RECEPTION','172.16.1.114','187.217.0.114','Disable',NULL),(43,'COM044','FO','Thezign','รวม','7431','Intel(R) Core(TM) i3-4150 CPU @ 3.50GHz','8GB',NULL,'SAMSUNG','Logiteh','K120','To Be Filled By O.E.M.',NULL,'1TB',NULL,'-',NULL,'Microsoft Windows 10','798180250','585422693','PC-PC','172.16.1.102','187.217.0.102','',NULL),(44,'COM045','FO','Thezign','Vingcard','4','Intel(R) Pentium(R) CPU G2020 @ 2.90GHz','2GB',NULL,'Lenovo L193 Wide, 18.6\" (40cm x 25cm)','45','Lenovo','Gigabyte Technology co.Ltd. H61M-S2P-R3',NULL,'1TB',NULL,'ZU034',NULL,'Microsoft Windows 7 ','844798411','307487051','FRONTA','172.16.1.247','187.217.0.247','',NULL),(45,'COM046','FO','Thezign','Oper','7000','Genuine Intel(R) CPU            2140  @ 1.60GHz','2048MB',NULL,'HP HP L1706, 17.1\" (34cm x 27cm)','HP','OKER','',NULL,'149.1GB',NULL,'ZU035',NULL,'Microsoft Windows 7 ','-','671966100','OPER-PC','172.16.1.116','187.217.0.116','Disable',NULL),(46,'COM047','FO','Thezign','คุณอเล็กซ์','7421','Pentium(R) Dual-Core  CPU      E5300  @ 2.60GHz','2941MB',NULL,'SAMSUNG SyncMaster, 17.1\" (34cm x 27cm)',' PHILIPS',' PHILIPS','7515RT5 R8LAWKE',NULL,'465.8GB',NULL,'ZU036',NULL,'Microsoft Windows 7 ','1036909826','382681714','ADMIN-97089B45B','172.16.1.45','187.217.0.45','',NULL),(47,'COM048','FO','Thezign','คุณกิ๊ก','7420','Intel(R) Pentium(R) D CPU 3.40GHz','1057MB',NULL,'SAMSUNG 1024 x 768 pixels, true colour','MD tech','PHILIPS','0A50h',NULL,'74.5GB',NULL,'ZU037',NULL,'Microsoft Windows XP','130583281','376360588','NAMTHIPPC','172.16.1.101','187.217.0.101','Enable',NULL),(48,'COM049','FO','Thezign','คุณต้อ','7422','Intel(R) Celeron(R) CPU G550 @ 2.60GHz','1729MB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','KER L7-300','HP','ASUSTek COMPUTER INC. P8H61-MLX R2.0',NULL,'465.8GB',NULL,'ZU097',NULL,'Microsoft Windows 7 ','114380976','328347203','ZHASTFO01','172.16.1.103','187.217.0.103','Enable',NULL),(49,'COM050','AC','Thezign','คุณนุ๊ย หลังฟร้อน','7423','Intel(R) Pentium(R) Gold G5400 CPU @ 3.70GHz ','4 GB',NULL,'ABISU ','Lenovo','Lenovo','945GCM-S2L',NULL,'240 GB',NULL,'ZU038',NULL,'Windows 10','1103651163','470662601','ZHCASHIE','187.217.0.197','172.16.1.197','Enable',NULL),(50,'COM051','FO','Thezign','คุณนิด','7433','Intel(R) Pentium(R) CPU G630 @ 2.70GHz','1024MB',NULL,'Samsung S20B300, 19.9\" (44cm x 25cm)','Logitech M100r','Lenovo','Model:1607Y1T    Serial Number:PBGLLK7	 ',NULL,'465.8GB',NULL,'ZU039',NULL,'Microsoft Windows 7 ','214018366','904767994','ZHFRONTOFFICE','172.16.1.107','187.217.0.107','Enable',NULL),(51,'COM052','Reservation','Thezign','ฝึกงาน','-','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','1024MB',NULL,'HP L1706, 17.1\" (34cm x 27cm)','Logitech','Logitech','-',NULL,'74.5GB',NULL,'ZU040',NULL,'Microsoft Windows XP','1007925788','-','ZHRSVN3','172.16.1.87','187.217.0.87','Disable',NULL),(52,'COM053','Reservation','Thezign','ฝึกงาน','7436','Intel(R) Pentium(R) 4 CPU 3.00GHz','1024MB',NULL,'SAMSUNG SyncMaster, 17.1\" (34cm x 27cm)','-','Lenovo','P5L-MX SYS-1234567890',NULL,'74.5GB',NULL,'ZU041',NULL,'Microsoft Windows XP','1055951579','397582863','ZHRSVN4','187.217.0.112','172.16.1.112','Enable',NULL),(53,'COM054','Reservation','Thezign','คุณมิ้น','7435','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','1024MB',NULL,'Lenovo LEN LS1922wA, 18.5\" (41cm x 23cm)','Lenovo','Lenovo','Gigabyte Technology Co., Ltd.   Model: 945GCM-S2L	',NULL,'931.5GB',NULL,'ZU042',NULL,'Microsoft Windows 7 ','1057029635','253668854','ZHRSVN01-PC','172.16.1.111','187.217.0.111','Enable',NULL),(54,'COM055','Reservation','Thezign','คุณปิงปอง','7434','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','1024MB',NULL,'RDT196LM, 19.1\" (38cm x 30cm)','HP','Logitech','P5G-MX',NULL,'149.0GB',NULL,'-',NULL,'Microsoft Windows XP','562436524','462158655','ZHRESERVATION02','172.16.1.110','187.217.0.110','Enable',NULL),(55,'COM056','Artis','Thezign','พี่เปิ้ล','7320','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','3072MB',NULL,'sumsung SyncMaster, 17.1\" (34cm x 27cm)','Genius','Logitech ','System Product Name SYS-1234567890',NULL,'232.9GB',NULL,'ZU043',NULL,'Microsoft Windows 7 ','992407918','-','ART_ZIGN','172.16.1.230','-','Enable',NULL),(56,'COM057','Artis','Thezign','พี่เจี้ยง','7320','Intel(R) Core(TM)2 Duo CPU     E7400  @ 2.80GHz','2048MB',NULL,'Samsung G195HQL, 18.5\" (41cm x 23cm)','Nubwo NM-84','HP','Model:KY787AA-AKL p6172l Serial Number:CNX9270LNB',NULL,'465.8GB',NULL,'-',NULL,'Microsoft Windows XP','745380404','455405818','DARKEDITION','172.16.1.231','-','Enable',NULL),(57,'COM058','Reservation','Thezign','คุณตั๊ก','7438','Genuine Intel(R) CPU 2160  @ 1.80GHz','2048MB',NULL,'SAMSUNG SyncMaster, 17.1\" (34cm x 27cm)','45','Logitech','HP Compaq dx2300 Microtower',NULL,'931.5GB',NULL,'ZU045',NULL,'Microsoft Windows 7 ','618400509','952026894','RSVNTHEZIGN','172.16.1.109','187.217.0.109','Enable',NULL),(58,'COM059','Reservation','Thezign','คุณหนู','7437','Pentium(R) Dual-Core  CPU      E5500  @ 2.80GHz','3197MB',NULL,'Samsung 1024 x 768 pixels, true colour','Lenovo','Logitech K120','Model:7099G5T	   Serial Number: S5BLMPG	 ',NULL,'931.5GB',NULL,'-',NULL,'Microsoft Windows 7 ','671530186','603638566','ZHSALE02','172.16.1.92','187.217.0.92','Enable',NULL),(59,'COM060','Sale','Thezign','คุณอุ๊','7700','Intel(R) Pentium(R) CPU G3420 @ 3.20GHz','3481MB',NULL,'Compaq Q2009, 19.9\" (44cm x 25cm)','anitech','anitech','H81M-DS2',NULL,'1.13TB',NULL,'ZU046',NULL,'Microsoft Windows 7 ','209021510','307156975','ZHSALEMGR','172.16.1.122','187.217.0.122','Enable',NULL),(60,'COM061','Sale','Thezign','คุณเตย','7702','Intel(R) Pentium(R) Dual  CPU  E2140  @ 1.60GHz','1024MB',NULL,'SAMSUNG SyncMaster, 17.1\" (34cm x 27cm)','Lenovo','MD tech','P5GC-MX',NULL,'465.8GB',NULL,'ZU047',NULL,'Microsoft Windows XP','896654057','595585280','ZHASTSAL','172.16.1.123','187.217.0.123','Enable',NULL),(61,'COM062','Sale','Thezign','คุณเจี๊ยบ','7703','Intel(R) Core(TM) i3-4160 CPU @ 3.60GHz','3769MB',NULL,'Samsung SyncMaster, 17.1\" (34cm x 27cm)','Wireless mouse','MD tech','ASRock H81M-VG4 R2.0',NULL,'931.5GB',NULL,'ZU048',NULL,'Microsoft Windows 10','629273044','877792249','ZHRESERRATION04','172.16.1.121','187.217.0.121','Enable',NULL),(62,'COM063','Dessin','Thezign','แคชเชียร์','7324','Intel(R) Pentium(R) Dual  CPU  E2160  @ 1.80GHz','1024MB',NULL,'Philips 206VL, 19.9\" (44cm x 25cm)','KER','Logitech','Gigabyte Technology Co., Ltd. 945GCM-S2L',NULL,'149.0GB',NULL,'ZU049',NULL,'Microsoft Windows XP','1080825965','-','DESSIN','172.16.1.237','187.217.0.237','Disable',NULL),(63,'COM064','Chifan','Thezign','แคชเชียร์','7386','Genuine Inte(R) CPU 2140@ 1.60GHz','512MB',NULL,'1024x768 pixels, true colour','Lenovo','Lenovo','INVALID',NULL,'149.0GB',NULL,'ZU052',NULL,'Microsoft Windows XP','312277246','-','CHIFAN','187.217.0.48','172.16.1.48','Disable',NULL),(64,'COM065','Scarlet','Thezign','แคชเชียร์','7326','Pentium(R) Dual-Core  CPU      E5400  @ 2.70GHz','1024MB',NULL,'1024 x 768 pixels, true colour','MD tech','lenovo','7270RW1 R82EK4W',NULL,'298.1GB',NULL,'ZU050',NULL,'Microsoft Windows XP','-','296 447 72','SCARLET','187.217.0.193','172.16.1.193','Disable',NULL),(65,'COM066','AC','Thezign','แคชเชียร์ Villa','7471','Intel(R) Core(TM)2 CPU          6400  @ 2.13GHz','1057MB',NULL,'NEC AS192M, 19.1\" (38cm x 30cm)','Genius','MD tech','Hewlett-psckard 0A54h',NULL,'74.5GB',NULL,'-',NULL,'Microsoft Windows XP','648354487','140229947','ZHCHRVILLA1','172.16.1.118','187.217.0.118','Disable',NULL),(66,'COM067','FO Villa','Thezign','รวม','7470','Intel(R) Pentium(R) CPU G870 @ 3.10GHz','2048MB',NULL,'NEC RDT1711LM, 17.1\" (34cm x 27cm)','KER','HP','HP PrO 3330 Microtower PC',NULL,'931.5GB',NULL,'-',NULL,'Microsoft Windows 10','184076477','847895220','FRONTVILLA01','172.16.1.119','187.217.0.119','Enable',NULL),(67,'COM068','FO','Thezign','รวม ตึกB','7460','Genuine Intel(R) CPU 2140  @ 1.60GHz','1024MB',NULL,'AS171M, 17.1\" (34cm x 27cm)','Logitech M100r','Logitech K120','-',NULL,'298.1GB',NULL,'-',NULL,'Microsoft Windows 7 ','147518658','614879822','FRONT_B1','172.16.1.105','187.217.0.105','Disable',NULL),(68,'COM069','IT','Thezign','ต่าย','7367','Intel(R) Core(TM) i3-6100 CPU @ 3.70GHz','4096MB',NULL,'Samsung S22B300, 19.9\" (44cm x 25cm)','45','Lenovo','BIOSTAR Group H110MDS2 PRO D4',NULL,'931.5GB',NULL,'ZU055',NULL,'Microsoft Windows 10','1013028589','844582112','IT-SUPPORT7','172.16.1.243','187.217.0.243','Enable',NULL),(69,'COM070','IT','Thezign','ไนช์','7367','Intel(R) Pentium(R) Gold G5500 CPU @ 3.80GHz','3753MB',NULL,'Acer G195HQL, 18.5\"','USB OKER','Lenovo KU-0225','-',NULL,'223.6GB',NULL,'-',NULL,'Microsoft Windows 10','1005080210','54618967','DESKTOP-49OJOQ4','172.16.1.239','187.217.0.239','Enable',NULL),(70,'COM071','HK Villa','Thezign','คุณสัน','7140','Genuine Intel(R) CPU 2160  @ 1.80GHz ','3GB',NULL,'SAMSUNG SyncMaster, 17.1\" (34cm x 27cm)','Logitec','MD Tech KB-666','-',NULL,'240GB',NULL,'UZ071 ',NULL,'Microsoft Windows 7','204615140','857977432','HKVILLA1 ','172.16.1.153','187.217.0.153','Enable',NULL),(71,'COM072','HK Villa','Thezign','คุณรังสิมา','-','Intel(R) Pentium(R) Dual  CPU  E2200  @ 2.20GHz','1024MB',NULL,'SAMSUNG SyncMaster, 19.1\" (38cm x 30cm)','-','GIZZ','P5KPL-AM',NULL,'931.5GB',NULL,'ZU072',NULL,'Microsoft Windows 7 ','1076680315','147 274 78','HKVILLA-PC','192.16.1.155','187.217.0.155','Enable',NULL),(72,'COM073','IT','Thezign','ตาล','7368','Intel(R) Core(TM) i3-6098P CPU @ 3.60GHz','3791MB',NULL,'Samsung S19D300, 18.5\" (41cm x 23cm)','45','KER','ASRock H110M-DVS R3.0',NULL,'931.5GB',NULL,'ZU054',NULL,'Microsoft Windows 10','1056623180','109927665','ITSUPPORT8','172.16.1.238','187.217.0.238','Enable',NULL),(73,'COM074','IT','Thezign','Suriyan','7637','Intel(R) Core(TM) i3-6100 CPU @ 3.70GHz','DDR4 4GB',NULL,'PHILIPS','KER','DELL','ASROCK H110M-DVS V3',NULL,'SSD 240GB',NULL,'-',NULL,'10','444032697','444032697','ITSUPERVISOR','172.16.1.244','187.237.0.244','Enable',NULL),(74,'COM075','Mood','Thezign','แคชเชียร์','7363','Genuine Intel(R) CPU            2140  @ 1.60GHz','2048MB',NULL,'LCD-AD196G  , 19.1\" (38cm x 30cm)','KER','singno','-',NULL,'140GB',NULL,'ZU075',NULL,'Microsoft Windows XP','447603699','-','MOODS','172.16.1.120','187.217.0.120','Disable',NULL),(75,'COM076','FO','Thezign','Interface โทรศัพท์ ','0','Intel(R) Pentium(R) CPU G870 @ 3.10GHz','2048MB',NULL,'HP L1706, 16.8\" (33cm x 27cm)','-','-','Model:HP Pro 3330 MT  Serial Number:SGH229THJV',NULL,'931.5GB',NULL,'ZU056ZU057',NULL,'Microsoft Windows XP','1013142959','-','INTERFACESERVER','172.16.1.154','187.217.0.154','Enable',NULL),(76,'COM077','Guest A','Thezign','Guest ตึก A','-','Intel Pentium(R) Dual CPU E2160 @ 1.80GHz x2','985.1 MiB',NULL,'Lenovo','Lenovo','Lenovo','-',NULL,'313.9 GB',NULL,'-',NULL,'Linux','-','-','itsupport','-','-','Enable',NULL),(77,'COM078','Guest A','Thezign','Guest ตึก A','-','Pentium(R) Dual-Core CPU E5300 @ 2.60GHz x 2','958.5MB',NULL,'lenovo','lenovo','lenovo','-',NULL,'245.0GB',NULL,'-',NULL,'Linux','-','-','-','-','-',NULL,NULL),(78,'COM079','Guest B','Thezign','Guest ตึก B','-','Pentium(R) Dual-Core CPU E5300 @ 2.60GHz','977MB',NULL,'Levono','Logitech K120','Logitech M100','-',NULL,'268.1GB',NULL,'-',NULL,'Pearl Linux 6.0 (art','-','-','-','-','-',NULL,NULL),(79,'COM080','Guest B','Thezign','Guest ตึก B','-','Pentium(R) Dual-Core  E5300 @ 2.60GHz 2603.00 MHz','977MB',NULL,'lenovo 1366X768 pixels','lenovo','lenovo','To be filled by O.E.M',NULL,'292.4GB',NULL,'-',NULL,'Linux 4.13.0-16-gene','-','-','Guestthezign1','-','-',NULL,NULL),(80,'COM081','EXC','Thezign','พี่เอ','7410','Intel(R) Pentium(R) CPU G4400 @ 3.30GHz','4GB',NULL,'Lenovo L193 Wide, 18.6\" (40cm x 25cm)','Lenovo','Logitech','BIOSTAR Group H110MDS2 PRO D4',NULL,'1TB',NULL,'ZU058',NULL,'Microsoft Windows 10','1173947965','394344256','ZHGMX','172.16.1.97','-','Enable',NULL),(81,'COM082','MK','Thezign','เชฟเก่ง','-','Pentium(R) Dual-Core  CPU      E5700  @ 3.00GHz','1024MB',NULL,'SaMSUNG 1280 x 768 pixels, true colour','Lohitech M100r','Lenovo','Model: 0829AW2	 Serial Number:R8W2Z3K',NULL,'465.8GB',NULL,'-',NULL,'Microsoft Windows 7','1216967145','125469582','ZHCHEF03','172.16.1.158','-','Enable',NULL),(82,'COM083','IT','Thezign','เปาะ','7367','Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz','3241MB',NULL,'compak','45','lenovo','HP Compaq 6200 Pro MT PC',NULL,'931.5GB',NULL,'ZU053',NULL,'Microsoft Windows 7 ','430317532','672578773','ITSUPPORT-5-PC','172.16.1.241','187.217.0.241','Enable',NULL),(83,'COM086','IT','Thezign','รวม','7367','','',NULL,'','','',NULL,NULL,'',NULL,'-',NULL,'','','','ITSUPPORT-PC','-','-',NULL,NULL),(84,'COM087','IT','Thezign','พี่โจ้','7366','Intel(R)Core(TM)',NULL,NULL,'','','',NULL,NULL,'',NULL,'ZU108',NULL,'-','-','-','-','172.16.1.99','187.217.0.99',NULL,NULL),(85,'COM091','Control','Thezign','เครื่องServer','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','172.16.1.26','-','Disable',NULL),(86,'COM092','Control','Thezign','เครื่องServer','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','','187.217.0.252','-','Disable',NULL),(87,'COM093','Control','Thezign','เครื่องServer','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','172.16.1.253','-','Disable',NULL),(88,'COM094','Control','Thezign','เครื่องServer','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','172.16.1.5','-','Disable',NULL),(89,'COM095','IT','Thezign','เครื่องServer','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','172.16.1.2','-','Disable',NULL),(90,'COM096','Control','Thezign','เครื่องServer','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','172.16.1.10','-','Disable',NULL),(91,'COM100','IT','Thezign','โน๊คบุ๊ค HP','7367','Intel(R)','',NULL,'','','',NULL,NULL,'',NULL,'-',NULL,'Microsoft windows 10','-','-','LAPTOP-0R4PTDNS','-','-',NULL,NULL),(92,'COM102','IT','Thezign','โน๊คบุ๊ค Toshiba ขาว','7367','-','-',NULL,'-','-','-','-',NULL,'-',NULL,'-',NULL,'-','-','-','-','-','-','Enable',NULL),(93,'COM103','IT','Thezign','โน๊คบุ๊ค Toshiba ดำ','7367','Intel(R)','',NULL,'','','',NULL,NULL,'',NULL,'-',NULL,'Microsoft windows 7','-','-','IT_zign3','-','-',NULL,NULL),(94,'COM104','HK','Thezign','คุณแม่สมจิตร','7121','Intel(R) Pentium(R) Dual  CPU E5400 @3.70GHz','4GB',NULL,'-','-','-','-',NULL,'240GB',NULL,'ZU115',NULL,'Microsoft Windows 10','-','-','DESKTOP-PAS2TON','172.16.1.159','187.217.0.159','Enable',NULL),(95,'COM105','FO','Thezign','รวม','4','Intel(R) Pentium(R) Gold G5400 @ 3.70GHz','4GB',NULL,'','','',NULL,NULL,'240GB',NULL,'-',NULL,'Microsoft Windows 10','-','719519404','DESKTOP-K8H0NPG','172.16.1.224','187.217.0.224',NULL,NULL),(96,'COM106','FO','Thezign','โน๊ตบุ๊ค','4','Intel(R) Core(TM)i3-4005U CPU@1.70GHz','4GB',NULL,'-','-','-','-',NULL,'500GB',NULL,'-',NULL,'Microsoft windows 8','-','-','ZHF_Notebook','172.16.1.170','187.217.0.170','Enable',NULL),(97,'COM107','Sale','Thezign','พี่อ้อม','-','Intel(R)Pentium(R) Dual CPU E2140 @1.60GHz','2GB',NULL,'Samsung','-','-','-',NULL,'1TB',NULL,'-',NULL,'Microsoft windows7','-','-','ZHSALE4','172.16.1.124','187.217.0.124','Enable',NULL),(98,'COM108','MK','Thezign','คุณหนูนา','7371','Intel(R) Pentium(R) Gold G5400 CPU @ 3.70GHz','4GB',NULL,'Lenovo L193 Wide, 18.6\" (40cm x 25cm)','Nobi NM51BK','Lenovo','AsRock H310CM-DVS',NULL,'240GB',NULL,'-',NULL,'Microsoft Windows 10 Pro 64-Bit','1171913682','642100563','ZHCHEF01','172.16.1.157','187.217.0.157','Enable',NULL),(99,'COM109','-','Thezign','สแปร','-','Intel(R) Core(TM)i3-8100 CPU@3.60GHz','4GB',NULL,'-','-','-','ASRock H310CM-DVS',NULL,'240GB',NULL,'-',NULL,'Microsof Windows 10','1206572154','860154963','-','-','-',NULL,NULL),(100,'COM110','-','Thezign','สแปร','-','Intel(R) Core(TM) i3-8100 CPU@3.60GHz','4GB',NULL,'-','-','-','ASRock H310CM-DVS',NULL,'240GB',NULL,'-',NULL,'Microsoft Windows 10','1202225034','577448036','-','-','-',NULL,NULL),(101,'COM112','EN','Thezign','โน๊ตบุ๊ค ช่างซาวน์','7511','Intel(R) Core(TM)i3-7100U CPU@2.40GHz','4GB',NULL,'Dell','-','-','-',NULL,'1TB',NULL,'-',NULL,'Micrisoft Windows 10 ','1262109972','617597550','SOUND','-','-','Enable',NULL),(102,'COM113','spare','Thezign','-','-','Intel(R) core(TM)i3-8100','4 GB',NULL,'-','-','-','ASRock H310CM-DVS',NULL,'240 GB SSD',NULL,'',NULL,'Windows 10 32Bit','1496545030','483907618','spare-Thezign','-','-','Enable',NULL),(103,'COM114','spare','Thezign','-','-','Genuine Intel(R) CPU 2140@1.60GHz','1.5GB',NULL,'-','-','-','ASUSTek computer INc P5GC-MX',NULL,'1TB',NULL,'-',NULL,'Windows 7 32Bit','1280290895','399093782','spare','-','-','Enable',NULL),(104,'COM115','EXC','Thezign','คุณเปิ้ล','-','Intel(R) Pentiun(R) CPU G3420 @3.20GHz','4GB',NULL,'LG FLATRON L1760TR','Lenovo','Logitech','LALSKA-1072009',NULL,'1TB',NULL,'-',NULL,'Windows 10  64Bit','-','-','DESTOP-0BSHJG','172.16.1.85','187.217.0.85','Enable',NULL),(105,'COM116','EXC','Thezign','คุณเปิ้ล','-','Intel(R) Core(TM)i3-4160 CPU@3.60GHz','4GB',NULL,'Samsung Syncmaster 732n','LX Gaming KER','HP','ALASKA-1072009',NULL,'120GB SSD',NULL,'-',NULL,'Windows 10 64Bit','-','-','thezignac','172.16.1.167','187.217.0.167','Enable',NULL),(106,'COM117','EXC','Thezign','GM','-','Intel(R) Core(TM)i3-4150 CPU@3.50GHz','8GB',NULL,'Acer','Logitech','Logitech','ASUS 1072009',NULL,'1TB',NULL,'-',NULL,'Windows 7 32Bit','-','-','GM-PC','172.16.1.98','187.217.0.98,20.1.1.98','Enable',NULL),(107,'COM118','Sale','Thezign','ฝึกงาน','-','Intel(R) Pentium(R) Dual CPU E2140 @1.60GHz','1GB',NULL,'HP L1706','Optical','PHILIPS','ASUSTek Computer INC. P5G-Mx',NULL,'80GB',NULL,'ZU116',NULL,'Windows XP','507901836','591462978','zhsales07','172.16.1.125','187.217.0.125','Enable',NULL),(108,'GCOM001','HR','Garden Seaview','-',NULL,'','',NULL,'','','',NULL,NULL,'',NULL,'-',NULL,'','1175303692','269370866','HR','192.168.1.171',NULL,NULL,NULL),(109,'GCOM002','AC','Garden Seaview','คุณนิธิ',NULL,'Core i3','4 GB',NULL,' Dell All in One','','Dell CN-0PRDV9-LO300-8B2-0TFA',NULL,NULL,'1 TB',NULL,'-',NULL,'Windows 10 64 Bit','1211504271','847555065','GSV2','192.168.1.54','-',NULL,NULL),(110,'GCOM003','Reservation','Garden Seaview','คุณโอ๊ะ',NULL,'Intel(R)Core(TM) Duo CPU E7400@2.80GHz','2GB',NULL,'-','-','-','ASUSTek computer INc P5KPL-AM',NULL,'500GB',NULL,'-',NULL,'Windows 7 32Bit','1272256264','745663037','GDS_ADM','192.168.1.145','-',NULL,NULL),(111,'TCOM001','FO','Tsix5','Fonrt','7212','G3240 @ 3.10GHz','4GB',NULL,'SAMSUNG','Genius','lenovo','LENOVO 10ASS00Y00',NULL,'931.5GB',NULL,NULL,NULL,'win 10 Pro 32-Bit','612281501','835860704','Tsix5LLL_FRONT_','167.237.3.113','-',NULL,NULL),(112,'TCOM002','FO','Tsix5','รวม','7778','G3240@3.10GHz','4GB',NULL,'LENOVO','Genius','lenovo','LENOVO',NULL,'931.5 MB',NULL,NULL,NULL,'windows10 pro 32-bit','607279462','485168755','GESKTOP-5URF8G6','167.237.3.112','-','Enable',NULL),(113,'TCOM003','FO','Tsix5','รวม','7778','Intel(R)Pentium(R)cpuG640 @2.80GHz','2GB',NULL,'SAMSUNG','lenovo','Microsoft Wired Keyboad500','lenovo',NULL,'465.8GM',NULL,NULL,NULL,'windows10','597130274','349175472','DESKTOP-OSLMOA6','192.168.2.115','167.237.2.115','Enable',NULL),(114,'TCOM004','Reservation','Tsix5','คุณซาย','7003','penntium G640 2.80 GHz','2GB',NULL,'Philis','Genius','Lenovo','3492 LET',NULL,'465.8 GB',NULL,NULL,NULL,'window xp profession','925832296','221866961','RSVN21','167.237.2.114','-',NULL,NULL),(115,'TCOM005','Sale','Tsix5','คุณใจ','7404','Pentium(R) Dual-core​E5300 2.60GHz','1GB',NULL,'PHILIPS','-','Lenovo ','7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'Win xp','488089407','570704965','SALES1','192.168.2.116','-',NULL,NULL),(116,'TCOM006','FO','Tsix5','คุณเพ็น','-','J3710 @ 1.60GHz','4GB',NULL,'hp','hp','hp','HP   20-c226d',NULL,'465.8GB',NULL,NULL,NULL,'win 10 Home single L','472439655','396083558','ASSIST_FO_Tsix5','167.237.2.219','-',NULL,NULL),(117,'TCOM007','Reservation','Tsix5','คุณรุ่ง','7413','Pentiun G3240 3.10  GHz','4GB',NULL,'Lenovo','Genius','Lenovo','10ASS00Y00',NULL,'931.5 GB',NULL,NULL,NULL,'window 8.1 professio','532122417','309992305','Tsix5III_FRON2','167.237.3.139','-',NULL,NULL),(118,'TCOM008','FO','Tsix5','คุณมิน','7413','J3710@1.60GHz','2GB',NULL,'HP','HP','HP','HP20-C226d',NULL,'465.8GB',NULL,NULL,NULL,'win10HomeSingle Lang','470594749','216646207','Tsix5_ECOMMERSE','167.237.2.220','192.168.2.220','Enable',NULL),(119,'TCOM009','FO','Tsix5','คุณอุ๋ย','7401','G640@2.80GHz','2GB',NULL,'PHILIPS','LENOVO','LENOVO','LENOVO',NULL,'465.8 GB',NULL,NULL,NULL,'XP Professional 32 b','1000564072','507147437','T2FO','192.168.2.113','167.237.3.112','Enable',NULL),(120,'TCOM010','AC','Tsix5','คุณหมิว','7716','I3-400SU 1.70 GHz','4GB',NULL,'DELL','Genius','DELL','DELL Inspiron 3542',NULL,'465.8 GB',NULL,NULL,NULL,'window 10 profession','652416953','-','Tsix5LLL_CASHIE','167.237.1.140','-',NULL,NULL),(121,'TCOM011','FN','Tsix5','แคชเชียร์','7416','G3240@3.10GHz','4GB',NULL,'SAMSUNG','LENOVO','LENOVO','LENOVO',NULL,'931.5 GB',NULL,NULL,NULL,'windows 10 Pro 32 bi','640792942','678881621','ADMIN','167.237.1.160','192.168.1.160','Enable',NULL),(122,'TCOM012','Laundry','Tsix5','คุณออย','-','G3240 3.10GHz','4GB',NULL,'SAMSUNG','Lenovo ','Lenovo ','10ASSOOYOO',NULL,'931.5GB',NULL,NULL,NULL,'Win 8.1 pro 32bit','1013405214','275100463','ADMINISTRATOR','167.237.3.152','-',NULL,NULL),(123,'TCOM013','Laundry','Tsix5','คุณหวาน','7574','G3240 @ 3.10GHz','4GB',NULL,'SAMSUNG','lenovo','lenovo','LENOVO 10ASS00Y00',NULL,'931.5GB',NULL,NULL,NULL,'win 8.1 Pro 64-Bit','1129857534','622211379','Tsix5III_LAUNDR','167.237.3.131','-',NULL,NULL),(124,'TCOM014','HR','Tsix5','รวม','-','G640@2.80 GHz','2GB',NULL,'SAMSUNG','GENIUS','LENOVO','3492LET',NULL,'465.8 GB',NULL,NULL,NULL,'windows7','372692873','599589210','ADMIN-PC','167.237.3.135','192.168.1.135','Enable',NULL),(125,'TCOM015','HR','Tsix5','รวม','-','G3240 @3.10 GHz','4GB',NULL,'PHILIPS','Lenovo ','Lenovo ','Lenovo 10ASS00Y00',NULL,'931.5 GB',NULL,NULL,NULL,'Windows 8','385655084','803087967','Tsix5LL_HR','192.168.0.137','167.237.3.136',NULL,NULL),(126,'TCOM016','Artis','Tsix5','คุณ​อี๊ด​','7604','G3240​ @ 3.10GHz','4GB',NULL,'SAMSUNG​','Lenovo ','Lenovo ','10ASSOOYOO',NULL,'931.5GB',NULL,NULL,NULL,'Win 8.1​ Pro 64bit','920819442','525918971','TSIX5III_ART','167.237.1.120','-',NULL,NULL),(127,'TCOM017','MK','Tsix5','เชฟยอน','-','G3240@3.10 GHz','4GB',NULL,'SAMSUNG','lenovo','lenovo','10ASS00Y00',NULL,'931.5GB',NULL,NULL,NULL,'windows8.1Pro64-bit','532105316','782486727','Tsix5III_CHEF','167.237.3.191','192.168.3.191','Enable',NULL),(128,'TCOM018','MK','Tsix5','เชฟยุท','-','G640 @ 2.80 GHz','2GB',NULL,'PHILIPS','lenovo','Genius','Lenovo, PBCFXNV',NULL,'465.8 GB',NULL,NULL,NULL,'Windows 7','782885224','651982704','MK123','192.168.2.155','167.237.2.155',NULL,NULL),(129,'TCOM019','MK','Tsix5','คุณไค','-','E5300 @ 2.60GHz','1GB',NULL,'lenovo','lenovo','lenovo','LENOVO 7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'win 7 ulti 32-Bit','925061597','672506317','ADMIN-PC','167.237.2.156','-',NULL,NULL),(130,'TCOM020','AC','Tsix5','แคชเชียร์','7707','G640@2.80GHz','2GB',NULL,'PHILIPS','lenovo','Lenovo','3492 LET',NULL,'465.8 GB',NULL,NULL,NULL,'windows 10 Pro 32 bi','192168163','-','POSACO','167.237.0.163','192.168.1.163',NULL,NULL),(131,'TCOM021','FO','Tsix5','รวม','-','G640 @ 2.80 GHz','2GB',NULL,'LG','Lenovo','Lenovo','Lenovo,PBCFNN',NULL,'465.8 GB',NULL,NULL,NULL,'Windows 10','676150075','234963795','DESKTOP-U3ASFCS','192.168.2.110','167.237.2.110',NULL,NULL),(132,'TCOM022','FO','Tsix5','Fonrt','-','G640 @ 2.80GHz','2GB',NULL,'PHILIPS','neo','lenovo','LENOVO 3492LET',NULL,'465.8GB',NULL,NULL,NULL,'win 10 Pro 32-Bit','674518659','999898592','T2OP','167.237.2.111','-',NULL,NULL),(133,'TCOM023','AC','Tsix5','Cashier','7402','G640 @ 2.80GHz','2GB',NULL,'PHILIPS','lenovo','lenovo','3492LET',NULL,'465.8GB',NULL,NULL,NULL,'Win 10 Pro 32bit','581135127','613943462','DESKTOP HBBFRRK','167.237.0.112','-',NULL,NULL),(134,'TCOM024','HK','Tsix5','รวม','4','G640 @ 2.80 GHz','2GB',NULL,'Thinkuision','Lenovo','Lenovo','Lenovo,B4GZLIT',NULL,'465.8 GB',NULL,NULL,NULL,'Windows XP','1265916194','478107293','HK','192.168.1.161','167.237.2.161',NULL,NULL),(135,'TCOM025','HM','Tsix5','คุณหนู','7001','G640@2.80GHz','2GB',NULL,'PHILIPS','Lenovo','Lenovo','3492 LET',NULL,'763.8GB',NULL,NULL,NULL,'windows7 Ultmant 32 ','111889520','-','HM-PC','167.237.2.117','192.168.2.117','Enable',NULL),(136,'TCOM026','FB','Tsix5','คุณเปีย','7704','E5300 @ 2.60 GHz','1GB',NULL,'Lenovo','Signo','Lenovo','Lenovo',NULL,'298.1 GB',NULL,NULL,NULL,'window xp profession','802224588','743414788','FB_365','192.168.1.101','-',NULL,NULL),(137,'TCOM028','FB','Tsix5','-','-','E5300 @ 2.60GHz','1GB',NULL,'lenovo','lenovo','lenovo','LENOVO 7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'XP Pro 32-Bit','429435817','596454696','INCOMF','167.237.2.59','-',NULL,NULL),(138,'TCOM029','FO','Tsix5','คุณวิชญา','7701','G640 @ 2.80 GHz','2GB',NULL,'PHILIPE','-','lenovo','3492LET',NULL,'465.8GB',NULL,NULL,NULL,'win 10 pro 32bit','605739996','123436735','RECEPTION','167.237.2.118','-',NULL,NULL),(139,'TCOM031','FB','Tsix5','FB','-','G640 @ 2.40 GHz','4GB',NULL,'Philips','Lenovo','Lenovo','Lenovo',NULL,'465.8 GB',NULL,NULL,NULL,'window xp profession','-','-','ASSTFB','192.168.2.120','-',NULL,NULL),(140,'TCOM032','AC','Tsix5','คุณตึ๋ง','7004','E5300 @ 2.60 GHz','1GB',NULL,'Lenovo','Lenovo','Lenovo','Lenovo',NULL,'298.1 GB',NULL,NULL,NULL,'window xp profession','740915545','869272311','365-POOLBAR','192.168.2.142','-',NULL,NULL),(141,'TCOM033','AC','Tsix5','คุณดา','7103','G3240@3.10GHz','4GB',NULL,'LG','anitech','lenovo','10ASS00Y00',NULL,'931.5GB',NULL,NULL,NULL,'windows8.1 Pro 32-bi','730962512','573297015','RECEIVING','167.237.2.137','192.168.2.137','Enable',NULL),(142,'TCOM034','AP','Tsix5','คุณออย','7201','E5300 @ 2.60GHz','1GB',NULL,'PHILIDS','Genius','lenovo','LENOVO 7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'XP Pro 32-Bit','1006278760','120810468','AP','167.237.2.138','-',NULL,NULL),(143,'TCOM035','AC','Tsix5','คุณท็อป','7204','G3240 @ 3.10GHz','4GB',NULL,'SAMSUNG','lenovo','lenovo','10ASSOOYOO',NULL,'931.5GB',NULL,NULL,NULL,'win 8.1 pro 64bit','543265353','247581205','Tsix5 III','167.237.2.136','-',NULL,NULL),(144,'TCOM036','AC','Tsix5','คุณสุธน','7202','E5300@2.60GHz','1.5GB',NULL,'lenovo','genius','lenovo','7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'windows xp Pro32-bit','1299061929','591385764','AC_365','192.168.2.132','167.237.2.132','Enable',NULL),(145,'TCOM037','AC','Tsix5','คุณปาน','-','4405U 2.10GHz','4GB',NULL,'ASUS','ASUS','ASUS','V221IC',NULL,'465.8GB',NULL,NULL,NULL,'win 10 64bit','1189882051','459229633','Tsix5_AC','167.237.1.170','-',NULL,NULL),(146,'TCOM038','AC','Tsix5','คุณปาน','-','3.40GHz','512MB',NULL,'lenovo','-','lenovo','HP compaq dx7300 Microtower',NULL,'74.5GB',NULL,NULL,NULL,'XP Pro 32-Bit','1338930538','-','DMY','167.237.2.133','-',NULL,NULL),(147,'TCOM039','AC','Tsix5','คุุณริน','7411','E5300 @ 2.60 GHz','1GB',NULL,'Lenovo','Logitech','HP','Lenovo',NULL,'298.1GB',NULL,NULL,NULL,'window 10 profession','741085827','-','365_STORE','192.168.2.135','-',NULL,NULL),(148,'TCOM040','AC','Tsix5','คุณหนิง','-','Silver J5005 1.50GHz','4GB',NULL,'lenovo','lenovo','lenovo','lenovo FOD7001LTA',NULL,'465.8GB',NULL,NULL,NULL,'win10 64Bit','1110713468','804038859','ACCTsix5P1','167.237.1.157','-',NULL,NULL),(149,'TCOM041','FO','Tsix5','Fo P1','-','E5300 @ 2.60GHz','1GB',NULL,'Lenovo','neo','neo','Lenovo',NULL,'298.1 GB',NULL,NULL,NULL,'window 10 profession','1236631442','218286792','DESKTOP-GHG5MH9','192.237.1.118','-',NULL,NULL),(150,'TCOM042','FO','Tsix5','Fo','7776','E5300 @ 2.60GHz','1GB',NULL,'lenovo','lenovo','lenovo','LENOVO 7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'win 10 Pro','666288111','176071254','DESKTOP-HBSBOLK','167.237.1.121','-',NULL,NULL),(151,'TCOM043','AC','Tsix5','แคชเชียร์','-','Dual-core E5300 @2.60GHz','3GB',NULL,'PHILIPS','Genius','lenovo','lenovo 7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'win 10 pro 32bit','1453531157','813644807','365CASHIER01','167.237.1.119','-',NULL,NULL),(152,'TCOM044','AC','Tsix5','DMY','7705','E5300@2.60GHz','1GB',NULL,'lenovo','lenovo','lenovo','7515RT5',NULL,'298.1GB',NULL,NULL,NULL,'windows 10 Pro 32-bi','674279451','-','DMY1','167.237.0.223','192.168.1.223','Enable',NULL),(153,'TCOM045','AC','Tsix5','แคชเชียร์','7210','G3240 @ 3.10GHz','4GB',NULL,'PHILIDS','MD Teeh','lenovo','LENOVO 10A5500Y00',NULL,'931.5GB',NULL,NULL,NULL,'win 10 Pro 32-Bit','572943084','-','ADMIN','167.237.3.185','-',NULL,NULL),(154,'TCOM046','AC','Tsix5','แคชเชียร์','7724','G3240 @ 3.10GHz','4GB',NULL,'SAMSUNG','Lenovo','Lenovo','Lenovo',NULL,'931.5 GB',NULL,NULL,NULL,'window 10 profession','1203474896','701462501','Tsix5III','172.16.10.11','-',NULL,NULL),(155,'TCOM047','AC','Tsix5','แคชเชียร์','-','Intel(R) Pemtium(R) Silver J5005 CPU@1.50GHz','4GB',NULL,'All In One','HP','HP','HP 8432',NULL,'1TB',NULL,NULL,NULL,'Microsoft Windows 10','1201099084','962438904','Cashies_Tsix5','167.237.3.149','192.168.3.149','Enable',NULL),(156,'TCOM048','EN','Tsix5','คุณเจต','-','Pentium(R) Dual-Core CPU E6700@3.20GHz ','1GB',NULL,'-','-','-','ASUSTek computer INc P5KPL-AM/PS',NULL,'250GB',NULL,NULL,NULL,'Microsoft Windows 7','1238292317','496930777','En365.25_2','167.237.3.151','-','Enable',NULL),(157,'TCOM049','Sale','Tsix5',' คุณน้ำ (ไม่มีฝาเคส1ข้าง)','-','','',NULL,'','','',NULL,NULL,'',NULL,NULL,NULL,'','1269083434','332500493','TSIX5','167.237.3.132','192.168.3.132',NULL,NULL),(158,'TCOM050','FO','Tsix5','','-',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1488368274','112109050','fo_365','',NULL,NULL,NULL),(159,'WCOM01','FO','way','Fo','3','Dual-core E5800 ','2GB',NULL,'lenovo','anitech','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'XP professional 32-B','997330848','397565809','WYFCASHIER','192.168.1.201','-',NULL,NULL),(160,'WCOM02','FO','way','Fo','7107','Dual-core E5800','2GB',NULL,'lenovo','genius','lenovo','lenovo',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','1012725388','-','WY-RECEPTION 1','192.168.1.103','-',NULL,NULL),(161,'WCOM03','FO','way','Fo','-','Dual-core E5800','2GB',NULL,'lenovo','genius','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','1277225469','858330134','WYRECEPT2','192.168.1.233','-',NULL,NULL),(162,'WCOM04','FO','way','เครื่องวิงการ์ด','-','Dual-core E5800','2GB',NULL,'lenovo','lenovo','lenovo','lenovo9 9CKT11AUS',NULL,'500GB',NULL,NULL,NULL,'XP 32-Bit','1011593256','263466895','vingcard','192.168.1.234','-',NULL,NULL),(163,'WCOM05','FO','way','คุณน้อย','-','dual core E5800','2GB',NULL,'lenovo','gentes','lenovo','lenovo 0864N7T',NULL,'500GB',NULL,NULL,NULL,'XP 32-Bit','1006361563','362979440','WYRO','192.168.1.111','-',NULL,NULL),(164,'WCOM06','FO ','way','คุณเล็ก','-','Pentiumr G4400','4GB',NULL,'lenovo','Gentes','lenovo','dell ingspiron32',NULL,'1TB',NULL,NULL,NULL,'10 Pro 64-Bit','681795707','178088013','DESKTOP581SPHM','192.168.1.159','-',NULL,NULL),(165,'WCOM07','FO','way','คุณนุก','-','Dual-core E5800','4GB',NULL,'lenovo',' lenovo',' lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','124853184','691912929','POOH','192.168.1.42','-',NULL,NULL),(166,'WCOM08','FO','way','interfacetel','-','dual core E5800','2GB',NULL,'lenovo','maxtech','logitech','lenovo 0864N7T',NULL,'1.82TB',NULL,NULL,NULL,'win7 Pro 32-Bit','732950562','436025248','WYINTERPACC','192.168.1.136','-',NULL,NULL),(167,'WCOM09','-','way','-','7001','Dual-core E5800','2GB',NULL,'lenovo','-','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 Pro 32-bit','584811691','115464431','WAYHOTEL-PC','192.168.1.158','-',NULL,NULL),(168,'WCOM10','Reservation','way','คุณใหม่','-','dual core E5800','2GB',NULL,'lenovo','Genius','lenovo','lenovo 0864N7T',NULL,'500GB',NULL,NULL,NULL,'win7 ultimate 32-Bit','586309929','483422967','WYSVN','192.168.1.240','-',NULL,NULL),(169,'WCOM11','Reservation','way','คุณปลา','7001','Dual-core E5800','2GB',NULL,'lenovo','lenovo','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','584811691','115464431','WAYHOTEL-PC','192.168.1.158','-',NULL,NULL),(170,'WCOM12','AC','way','แคชเชียร์','-','Dual core E5800','2GB',NULL,'lenovo','lenovo','lenovo','lenovo 064W7T',NULL,'500 GB',NULL,NULL,NULL,'win xp 32-Bit','102477609','-','EVE','192.968.1.37','-',NULL,NULL),(171,'WCOM13','FB','way','-','-','Dual core E6800','2GB',NULL,'lenovo','lenovo','lenovo','lenovo 0864N7T',NULL,'600GB',NULL,NULL,NULL,'win 7 ultimate 32-Bi','942482351','448439611','WYFBMGR','192.168.1.2','-',NULL,NULL),(172,'WCOM14','FB','way','-','-','Dual-core E5800','2GB',NULL,'lenovo','genius','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','971485472','562800090','WYFBR','192.168.1.142','-',NULL,NULL),(173,'WCOM15','EN','way','-','-','Dual-core E5800','2GB',NULL,'acer','genius','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','551450829','-','ENGINEER','192.168.1.167','-',NULL,NULL),(174,'WCOM16','HK','way','-','-','Dual core E6800','2GB',NULL,'lenovo','Genius','lenovo','lenovo 0864N7T',NULL,'500GB',NULL,NULL,NULL,'win xp 32-Bit','330678286','483592187','WY-HK','192.168.1.151','-',NULL,NULL),(175,'WCOM17','HR','way','HR','-','Dual core ','2GB',NULL,'lenovo','lenovo','lenovo','lenovo 0864N7T',NULL,'500GB',NULL,NULL,NULL,'win 7 ultimate 32-Bi','992855890','764964362','WYHR','192.168.1.93','-',NULL,NULL),(176,'WCOM18','AC','way','คุณนัน','7104','dual-core E5800','2GB',NULL,'lenovo','genius','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'XP professional 32-b','680904230','971488861','ADMIN-OBA-CD1CAC','192.168.1.130','-',NULL,NULL),(177,'WCOM19','AC','way','คุณอ๊อด','7101','Dual core E5800','2GB',NULL,'lenovo','lenovo','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'7 ultimate 32-Bit','987097379','302771066','WY-INCOME','192.168.1.134','-',NULL,NULL),(178,'WCOM20','AC','way','คุณเม','7105','inte(R)Pentiam(R) CPU G630,6.20 GHz','2GB',NULL,'acer','acer','acer','verition X 4610G',NULL,'465.8GB',NULL,NULL,NULL,'win7 Ultimate 32-bit','1007093804','491802670','ACCOST','192.168.1.131','-',NULL,NULL),(179,'WCOM21','AC','way','คุณจิ๊บ','7103','dual-core E5800','2GB',NULL,'lenovo','logitech','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 ultimate 32-bit','998485815','616865799','WYOM','192.168.1.137','192.168.1.1',NULL,NULL),(180,'WCOM22','MK','way','chef','-','dual-core E5800','2GB',NULL,'samsung','cubie','lenovo','lenovo 0864N7T',NULL,'465.8MB',NULL,NULL,NULL,'win7 Pro 32-Bit','353034648','859787044','CHEFWAY-PC','192.168.1.144','-',NULL,NULL),(181,'WCOM23','MK','way','chef','-','Dual-core E5800','2GB',NULL,'lenovo','logitech','lenovo','lenovo 0864N7T',NULL,'465.8GB',NULL,NULL,NULL,'win7 Ultimate 32-bit','624401465','-','CHEFS','192.168.1.143','-',NULL,NULL),(182,'Z2COM01','AC','Z-Through','คุณโค้ด','3','Intel(R) CORE(TM) 2 DUO CPU','1GB',NULL,'SAMSUNG','MD tech','Logitech','Hewlet-Packed 0B10H',NULL,'74.5 GB',NULL,'Z2U001',NULL,'WIN XP PROFESSIONAL ','596295915','317502240','SPAZIO','192.168.1.125','-',NULL,NULL),(183,'Z2COM02','FO','Z-Through','คุณบีม','1','Dual core CPU E5200','1GB',NULL,'lenovo','Logitech','Hp','Hp dx2310 MT (NA139PA)',NULL,'232.9GB',NULL,'Z2U002',NULL,'win 7 Pro 32-Bit','166378221','112745581','ADMINITRATOR-PC','192.168.1.111','-',NULL,NULL),(184,'Z2COM03','FO','Z-Through','คุณแซน','2','intel core 2 Duo 2.66 GHz','2GB',NULL,'Samsung','Geius','HP','Hewlet-Packed 0B10H',NULL,'232.9 GB',NULL,'Z2U003',NULL,'win 7 ultimate 32 bi','346409688','317502240','ADMIN-IT','192.168.1.110','-',NULL,NULL),(185,'Z2COM04','Operator','Z-Through','โอเปอร์เรเตอร์','0','Dual core CPU E2160','1GB',NULL,'NEC','45','Logitech','Hp dx2310 MT(NA139PA)',NULL,'80GB',NULL,'Z2U004',NULL,'win xp Professional ','147860371','270645413','Z2FO','192.168.1.112','-',NULL,NULL),(186,'Z2COM05','Reservation','Z-Through','คุณเบ็น','7908','Intel(R)core(TM)2DUO CPU','2.5GB',NULL,'AS191M.19.1','Genius','logitech','Hewlet-Packedob10H',NULL,'307.4 GB',NULL,'Z2U005',NULL,'Microsoft windows7','1105358699','878964484','ACC-PC','192.168.1.114','-',NULL,NULL),(187,'Z2COM08','HM','Z-Through','คุณโฉม','7913','Dual core CPU E5300','1GB',NULL,'lenovo','lenovo','lenovo','lenovo 7515RT5',NULL,'298.1GB',NULL,'Z2U008',NULL,'win xp Professional ','566544352','599818487','Z2-FOM','192.168.1.115','-',NULL,NULL),(188,'Z2COM10','HK','Z-Through','HK','-','Intel(R) Pentium(R) CPU G645 @2.90GHz','2GB',NULL,'','','',NULL,NULL,'',NULL,'-',NULL,'Win 7 Ultimate 32 bit','987552464','519906955','administrator','192.168.1.231','-',NULL,NULL);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `item` with 188 row(s)
--

--
-- Table structure for table `storemains`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storemains` (
  `storemain_id` int(12) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_item_in` datetime DEFAULT NULL,
  `item_in_stock` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_use` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_location_out` datetime DEFAULT NULL,
  `location_lend` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_lend` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_lend_out` datetime DEFAULT NULL,
  `date_lend_in` datetime DEFAULT NULL,
  `item_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`storemain_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storemains`
--

LOCK TABLES `storemains` WRITE;
/*!40000 ALTER TABLE `storemains` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `storemains` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `storemains` with 0 row(s)
--

--
-- Table structure for table `storemanus`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storemanus` (
  `storemanu_id` int(11) NOT NULL AUTO_INCREMENT,
  `storemanu_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`storemanu_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storemanus`
--

LOCK TABLES `storemanus` WRITE;
/*!40000 ALTER TABLE `storemanus` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `storemanus` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `storemanus` with 0 row(s)
--

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `users_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`users_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `users` VALUES (1,'nice','$2y$10$5qppTPfr16gRBdPpS2XHJug6cghXtpOO.D0rNYmtQCkHUKzab6fom','ingnice007@gmail.com','172.16.1.99','KipcdwkTTeEv7jQAkJK7fdYFplipVmkJnCZRpf1D','2019-08-10 10:34:30','2019-11-21 10:41:00'),(2,'tal','$2y$10$ni7DpS9ko4ooSQHCDiZFZuVLs4pP5Knp1VhyUE8YvEFj.59InDF4C','zhit_6@thezignhotel.com','172.16.1.238','RKclKsAmyeNhU4uJpUocASCMXuxjPnE9on250IU8','2019-08-21 10:45:07','2019-08-23 01:24:32');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `users` with 2 row(s)
--

--
-- Table structure for table `windows`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `windows` (
  `window_id` int(12) NOT NULL AUTO_INCREMENT,
  `window_titel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `window_main` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`window_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `windows`
--

LOCK TABLES `windows` WRITE;
/*!40000 ALTER TABLE `windows` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `windows` VALUES (1,'Microsoft Windows XP',NULL),(2,'Microsoft Windows 7',NULL),(3,'Microsoft Windows 8',NULL),(4,'Microsoft Windows 10',NULL);
/*!40000 ALTER TABLE `windows` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `windows` with 4 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Tue, 26 Nov 2019 08:35:52 +0100
