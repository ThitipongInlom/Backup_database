-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: devmystyle
-- ------------------------------------------------------
-- Server version 	5.5.5-10.3.16-MariaDB
-- Date: Sat, 23 Nov 2019 02:56:38 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses_product`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses_product` (
  `cs_pd_id` int(12) NOT NULL AUTO_INCREMENT COMMENT 'courses_product_id',
  `cd_type_blog` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cs_type_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_name',
  `cs_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_name',
  `cs_slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cs_yb_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_youtube_time',
  `cs_yb_lik` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_youtube_link',
  `cs_img_link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cs_code` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `cs_download` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cs_view` int(50) DEFAULT NULL COMMENT 'courses_view',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`cs_pd_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses_product`
--

LOCK TABLES `courses_product` WRITE;
/*!40000 ALTER TABLE `courses_product` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `courses_product` VALUES (13,'video','HTML','ตอนที่ 1 ภาษา HTML เบื้องต้น','ตอนที่-1-ภาษา-HTML-เบื้องต้น','6.03','fAYAEJ1XBDY','e617615ffdc69ffd69d913aef720efa270959a33.jpg',NULL,NULL,77,'2019-07-06 11:55:00','2019-09-06 04:01:23'),(14,'video','PHP','ตอนที่ 1 ภาษา PHP เบื้องต้น','ตอนที่-1-ภาษา-PHP-เบื้องต้น','8.42','kQMj4enOpVY','24564dad27569e8578ca893b0065137e21923977.jpg','<p>AA</p><p>AA</p><p>AAAA</p><p>AAAAAAA<br>AA<br>AA<br>AA<br>AA</p><p>AA</p><p>AA</p><p>AA</p><p>AA</p>',NULL,66,'2019-07-06 13:40:34','2019-09-23 08:09:04'),(15,'video','JavaScript','ตอนที่ 1 ภาษา JavaScript เบื้องต้น','ตอนที่-1-ภาษา-JavaScript-เบื้องต้น','10.59','IDmyFcj0gys','cf3c3ce9aa380fa7a9e13e0cb6a965283d9aced9.jpg',NULL,NULL,70,'2019-07-07 14:31:36','2019-09-05 04:13:46'),(16,'video','Bootstrap','ตอนที่ 1 Bootstrap เบื้องต้น','ตอนที่-1-Bootstrap-เบื้องต้น','8.35','jhkGP4bizuY','ae7c35da09e14adcf10004a1ad06923f1bcc37d5.jpg',NULL,NULL,44,'2019-07-07 15:38:59','2019-09-09 01:52:59'),(17,'video','CSS','ตอนที่ 1 CSS เบื้องต้น','ตอนที่-1-CSS-เบื้องต้น','7.56','fvgvDeu6TDI','e645fa4f058bf93c5846395ea50f88437c4fdb83.jpg',NULL,NULL,25,'2019-07-08 16:09:43','2019-10-09 08:19:48'),(18,'video','HTML','ตอนที่ 2 ภาษา HTML เบื้องต้น !','ตอนที่-2-ภาษา-HTML-เบื้องต้น-!','9.34','wlmldJx4uw4','7bd3597078d3327193e52a4f0304a2eed935a47a.jpg',NULL,NULL,32,'2019-07-08 16:30:19','2019-10-02 04:27:26'),(19,'blog','JavaScript','ทดสอบๆๆ','ทดสอบๆๆ',NULL,NULL,'34f201648e1e694afb86a100b59cd0d412b05613.jpg','<p>ทดสอบ<br>โ<br>ve.;veeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeAFSFAGAsfsasgฮฮฮฮE&lt;EP:GE&lt;GPepp,epg,ep,epg,epg,epeg<br>AAfef,pefe,fepfef,.pef,</p><p>&nbsp;</p><p>b</p><p>b</p><p>&nbsp;</p>',NULL,156,'2019-07-15 14:28:11','2019-09-23 08:09:27');
/*!40000 ALTER TABLE `courses_product` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `courses_product` with 7 row(s)
--

--
-- Table structure for table `courses_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses_type` (
  `cs_type_id` int(12) NOT NULL AUTO_INCREMENT COMMENT 'courses_type_id',
  `cs_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_name',
  `cs_ico` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_icon',
  `cs_bg_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_backgound_color',
  `cd_text_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_text_color',
  `cd_text_sub` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'courses_sub_text',
  `cd_view` int(50) DEFAULT NULL COMMENT 'courses_view',
  PRIMARY KEY (`cs_type_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses_type`
--

LOCK TABLES `courses_type` WRITE;
/*!40000 ALTER TABLE `courses_type` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `courses_type` VALUES (1,'HTML','fa-html5','#fe781e','#ffff','สอนการใช้งาน HTML 5',39),(2,'PHP','fa-php','#1570a6','#ffff','สอนการใช้งาน PHP',91),(3,'JavaScript','fab fa-js-square','#feb91e','#ffff','สอนการใช้งาน JavaScript',29),(4,'Bootstrap','fab fa-bootstrap','#9b59bb','#ffff','สอนการใช้งาน Bootstrap',26),(5,'CSS','fab fa-css3','#1ba1e2','#ffff','สอนการใช้งาน CSS',9);
/*!40000 ALTER TABLE `courses_type` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `courses_type` with 5 row(s)
--

--
-- Table structure for table `error_video`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `error_video` (
  `error_id` int(12) NOT NULL AUTO_INCREMENT,
  `video_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_datetime` datetime DEFAULT NULL,
  `error_member` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_guest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agen` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`error_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_video`
--

LOCK TABLES `error_video` WRITE;
/*!40000 ALTER TABLE `error_video` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `error_video` VALUES (4,'ตอนที่ 1 CSS เบื้องต้น','2019-08-27 16:39:21',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36');
/*!40000 ALTER TABLE `error_video` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `error_video` with 1 row(s)
--

--
-- Table structure for table `setting_web`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting_web` (
  `st_id` int(12) NOT NULL AUTO_INCREMENT,
  `st_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `st_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`st_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting_web`
--

LOCK TABLES `setting_web` WRITE;
/*!40000 ALTER TABLE `setting_web` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `setting_web` VALUES (1,'login_register','on'),(2,'version_web','0.0.3');
/*!40000 ALTER TABLE `setting_web` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `setting_web` with 2 row(s)
--

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` int(12) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `users` VALUES (3,'nice','$2y$10$wVmNKZdo9UjDEMptrkLVjeID3LIdDxCywd2ujdpHYNZwQobCroHS6','Thitipong','Inlom','male',22,'0864633160','ingnice007@gmail.com','admin','::1','SBaNHFi6mcxIDx6UJJF2UZXD58SBtKe9o0DIMO9b','2019-07-15 08:23:29','2019-09-23 06:47:28'),(4,'test','$2y$10$/.Doata4v7vdkRjwSdbqU.dSuQYV296HwtICGAxJRC7y83LKqc3wS','ทดสอบ','โปรแกรม','male',20,'-','-','user','::1','ctUpTCkcRkqYRgsMIK3Pfd15ddasEtaAmS2QkAd5F9m3xZSbpCAlMtwmjopo','2019-09-05 07:35:08','2019-09-10 08:50:08');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `users` with 2 row(s)
--

--
-- Table structure for table `version`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `ver_id` int(12) NOT NULL AUTO_INCREMENT,
  `ver_web` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ver_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `var_date` date DEFAULT NULL,
  PRIMARY KEY (`ver_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `version` VALUES (1,'0.0.1','ดึงคลิปจาก Youtube','2019-07-01'),(2,'0.0.1','ปุ่ม แชร์ Facebook','2019-07-08'),(3,'0.0.1','ปรับปรุง สีของ เว็บ','2019-07-09'),(4,'0.0.1','ปรับปรุง Support Mobile','2019-07-15'),(5,'0.0.1','ปรับปรุง เพิ่มรูป ภาพ พื้นหลัง','2019-07-15'),(6,'0.0.2','เพิ่มระบบ สมัครสมาชิก','2019-07-15'),(7,'0.0.2','เพิ่มระบบ ล็อกอิน ','2019-07-15'),(8,'0.0.2','เพิ่มการใช้งาน ปลั้กอิน ckeditor 5','2019-07-23'),(9,'0.0.2','เพิ่มการใช้งาน ปลั้กอิน Highlight','2019-07-28'),(13,'0.0.3','เพิ่มการใช้งาน LazyLoad กับรูปภาพ','2019-08-27');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `version` with 10 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Sat, 23 Nov 2019 02:56:38 +0100
